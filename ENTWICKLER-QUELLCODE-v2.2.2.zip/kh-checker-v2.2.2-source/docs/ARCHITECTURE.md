# KH Checker v2.2.2 – Architektur

## Leitprinzipien

1. Die veröffentlichte App ist eine statische, unter einem beliebigen HTTPS-Unterpfad installierbare PWA.
2. GitHub Pages liefert Dateien aus, führt aber keine Anwendungslogik serverseitig aus.
3. Such-, Ranking-, Cache-, Kalibrierungs- und Berechnungslogik läuft auf dem Endgerät.
4. Öffentliche API-Aufrufe werden durch Cache-first und In-Flight-Deduplizierung minimiert.
5. Eine Nutzer-Einheit wird nie stillschweigend umgedeutet.
6. Der Originalfehler bleibt beobachtbar, auch wenn ein Fallback funktioniert.
7. OpenAI ist optional und strukturiert höchstens Nutzersprache; es entscheidet keine Nährwerte oder Gewichte.

## Statischer Produktionspfad

```text
GitHub Pages / beliebiger HTTPS-Static-Host
  → relative App-Assets
  → Service Worker
  → lokale PWA-Laufzeit
  → direkte CORS-GETs zu Open Food Facts
```

Die App probt keinen `/api/health`-Endpunkt und erwartet keinen Same-Origin-Server. Nur eine ausdrücklich konfigurierte Gateway-URL ersetzt den direkten Suchtransport.

## Suchausführung

1. Eingabe wird von Klammern und Mehrfach-Leerzeichen bereinigt und auf 120 Zeichen begrenzt.
2. Bekannte Tippfehler werden lokal korrigiert.
3. Der kanonische Query-Key wird vor Cache und Netzwerk gebildet.
4. Frischer Canonical Cache wird vor jedem Netzwerkzugriff verwendet.
5. Kompatible URL-Caches älterer Releases können einmalig migriert werden.
6. Search-a-licious wird als primäre Volltextsuche aufgerufen.
7. OFF `cgi/search.pl` wird genau einmal aufgerufen, wenn Search-a-licious technisch fehlschlägt oder gültig null Treffer liefert.
8. Bei zwei erreichbaren Null-Treffer-Antworten wird ein typisierter Leerzustand gespeichert.
9. Stale Canonical Cache wird nur nach dem Scheitern beider Backends oder bei bekanntem Offline-Zustand verwendet.
10. Ohne Treffer oder Reserve wird ein typisierter Fehler an die UI geliefert; die Oberfläche bleibt sofort erneut bedienbar.

Ein ausdrücklich konfigurierter Gateway gilt als eigener autoritativer Transport und löst im Browser keine zusätzlichen öffentlichen Fallback-Aufrufe aus.

## Request Manager

### In-Flight-Deduplizierung

Jede konkrete GET-URL besitzt höchstens einen laufenden Netzwerktask. Mehrere Aufrufer abonnieren denselben Task. Das Abbrechen einer UI-Ansicht entfernt nur ihren Abonnenten; der gemeinsame Request kann von einem sofortigen Retry weiterverwendet werden.

### Zeitlimits und Fehler

Jeder Versuch speichert:

- Backend und lesbares Label
- vollständige URL
- Startzeit und Dauer
- Outcome und HTTP-Status
- originalen Fehlernamen und die Originalmeldung
- optional Antwortvorschau und `Retry-After`

Timeout, Netzwerk, Parse, HTTP und Remote-Rate-Limit bleiben unterscheidbar. `Retry-After` wird nur diagnostiziert und installiert keinen lokalen Lock.

### Höchstzahl

Pro Benutzer-Suchaktion werden höchstens zwei Suchbackends versucht. Produktdetails werden nur für den ausgewählten Kandidaten geladen; es gibt keinen Detail-Fan-out.

## Cache-Architektur

### Ebenen

1. begrenzter Memory-Cache
2. kompakter `localStorage`-Spiegel für kanonische Such- und Produkt-Snapshots
3. IndexedDB für URL-Caches und langlebige Snapshots

API-Cache-Writes aktualisieren Memory und den kompakten Spiegel zuerst; IndexedDB folgt asynchron. Ein Generationsschutz verhindert, dass ein verspäteter Write einen bewusst geleerten Cache wiederherstellt.

### Zeitstempel

Canonical Snapshots übernehmen das ursprüngliche `api_meta.fetchedAt`. Stale Daten werden nach einem fehlgeschlagenen Refresh nicht als frisch hochgestuft.

### Gültigkeiten

- erfolgreiche Suche: 24 Stunden frisch, 30 Tage Reserve
- leere Suche: 15 Minuten frisch, 24 Stunden Reserve
- Produkt: 30 Tage frisch, 180 Tage Reserve

## Produktdetails

1. Nur der ausgewählte oder eindeutig bestimmte Barcode wird hydratisiert.
2. Ein vorhandener Suchtreffer dient als Seed für Name, Menge, Portion und Nährwerte.
3. OFF API v3.6 ist der primäre Detailendpunkt.
4. OFF API v2 wird nur aufgerufen, wenn nach Seed plus v3.6 weiterhin Kohlenhydratdaten fehlen.
5. v3.6- und v2-Dokumente werden feldweise zusammengeführt.
6. Erreichbare Antworten ohne Produkt werden als HTTP 404 klassifiziert.
7. Nützliche Teildaten bleiben bei einem transienten v2-Ausfall verwendbar.

## Einheiten- und Kalibrierungsvertrag

Beweishierarchie:

1. explizite Nutzer-Einheit
2. gespeicherte Kalibrierung für dasselbe Produkt und dieselbe Einheit
3. explizites Einzelgewicht
4. aus Stückzahl und Nettogewicht abgeleitetes Einzelgewicht
5. Herstellerportion beziehungsweise Packungs- und Masseoptionen als zusätzliche Auswahl

Nicht zulässig:

- Stück ohne Bestätigung als Portion behandeln
- nackte `serving_quantity` als Stückgewicht interpretieren
- Verpackungsanzahl als essbare Stückzahl interpretieren
- typisches Gewicht schätzen
- Packung wählen, obwohl eine kleinere bewiesene Einheit existiert

Gruppenwägung verwendet `Gesamtgewicht / Anzahl`, mindestens zwei Einheiten. Gespeichert wird das präzise Gewicht, nicht ein historischer Kohlenhydratwert. Die Kohlenhydratmenge wird mit dem aktuellen Wert pro 100 g neu berechnet.

## PWA und GitHub Pages

- Vite-Basis: `./`
- Manifest `start_url`: `./`
- Manifest `scope`: `./`
- Display: `standalone`
- Apple-Touch-Icon vorhanden
- Service Worker wird sofort registriert und aktualisiert sich automatisch
- App-Shell wird precached
- OFF-Produktbilder werden 30 Tage Cache-first gehalten, maximal 80 Einträge
- API-JSON verbleibt außerhalb des Workbox-Runtime-Caches

Das Release-ZIP legt die gebauten Dateien direkt in den ZIP-Stamm. Damit kann der vorhandene Workflow sie ohne zusätzliche Build- oder Serverphase als Pages-Artefakt veröffentlichen.

## Optionaler Express-Server

`server/index.mjs` bleibt für lokale Entwicklung, bestehende Gateway-Deployments und den optionalen OpenAI-Parser erhalten. Seine Suchreihenfolge entspricht dem Client: Search-a-licious primär, Legacy nach technischem Fehler oder null Treffern. Dieser Server ist nicht Teil der erforderlichen Pages-Architektur.
