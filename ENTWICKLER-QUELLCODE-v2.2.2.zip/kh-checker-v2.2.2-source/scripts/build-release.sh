#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION="2.2.2"
OUTPUT_DIR="${OUTPUT_DIR:-$ROOT_DIR/release-out}"
SOURCE_ARCHIVE="ENTWICKLER-QUELLCODE-v${VERSION}.zip"
COMPLETE_ARCHIVE="kh-checker-v${VERSION}-komplett.zip"

for command in node npm rsync zip unzip sha256sum; do
  command -v "$command" >/dev/null 2>&1 || { echo "Benötigtes Werkzeug fehlt: $command" >&2; exit 1; }
done

mkdir -p "$OUTPUT_DIR"
OUTPUT_DIR="$(cd "$OUTPUT_DIR" && pwd)"
WORK_DIR="$(mktemp -d)"
trap 'rm -rf "$WORK_DIR"' EXIT

cd "$ROOT_DIR"
if [[ "${RELEASE_SKIP_CHECK:-0}" != "1" ]]; then
  npm run check
fi

SOURCE_STAGE="$WORK_DIR/source/kh-checker-v${VERSION}-source"
mkdir -p "$SOURCE_STAGE"
rsync -a ./ "$SOURCE_STAGE/" \
  --exclude '.git/' \
  --exclude 'node_modules/' \
  --exclude 'dist/' \
  --exclude 'release-out/' \
  --exclude '*.tsbuildinfo' \
  --exclude '.env'

rm -f "$OUTPUT_DIR/$SOURCE_ARCHIVE" "$OUTPUT_DIR/$COMPLETE_ARCHIVE"
(
  cd "$WORK_DIR/source"
  zip -X -q -r "$OUTPUT_DIR/$SOURCE_ARCHIVE" "kh-checker-v${VERSION}-source"
)

SITE_STAGE="$WORK_DIR/site"
mkdir -p "$SITE_STAGE"
rsync -a "$ROOT_DIR/dist/" "$SITE_STAGE/"
cp "$ROOT_DIR/LICENSE" "$SITE_STAGE/LICENSE"
cp "$ROOT_DIR/README.md" "$SITE_STAGE/README.md"
cp "$ROOT_DIR/CHANGELOG.md" "$SITE_STAGE/CHANGELOG.md"
cp "$ROOT_DIR/README-ERST-LESEN.txt" "$SITE_STAGE/README-ERST-LESEN.txt"
cp "$ROOT_DIR/RELEASE-NOTES-v${VERSION}.txt" "$SITE_STAGE/RELEASE-NOTES-v${VERSION}.txt"
cp "$OUTPUT_DIR/$SOURCE_ARCHIVE" "$SITE_STAGE/$SOURCE_ARCHIVE"
printf 'KH Checker v%s\nBuild date: 2026-07-11\nDeployment: static GitHub Pages PWA\n' "$VERSION" > "$SITE_STAGE/VERSION.txt"

(
  cd "$SITE_STAGE"
  find . -type f ! -name 'SHA256SUMS.txt' -print0 \
    | sort -z \
    | xargs -0 sha256sum \
    | sed 's#  \./#  #' > SHA256SUMS.txt
  zip -X -q -r "$OUTPUT_DIR/$COMPLETE_ARCHIVE" .
)

"$ROOT_DIR/scripts/verify-release.sh" "$OUTPUT_DIR/$COMPLETE_ARCHIVE"
"$ROOT_DIR/scripts/verify-pages-workflow.sh" "$OUTPUT_DIR/$COMPLETE_ARCHIVE"
printf '%s\n' "$OUTPUT_DIR/$SOURCE_ARCHIVE" "$OUTPUT_DIR/$COMPLETE_ARCHIVE"
