#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ZIP_PATH="${1:?Aufruf: scripts/verify-release.sh /pfad/kh-checker-v2.2.2-komplett.zip}"
ZIP_PATH="$(cd "$(dirname "$ZIP_PATH")" && pwd)/$(basename "$ZIP_PATH")"

unzip -tq "$ZIP_PATH" >/dev/null
if unzip -Z1 "$ZIP_PATH" | grep -Eq '(^|/)\.\.?(/|$)|^/'; then
  echo "Unsicherer ZIP-Pfad erkannt." >&2
  exit 1
fi

WORK_DIR="$(mktemp -d)"
trap 'rm -rf "$WORK_DIR"' EXIT
unzip -q "$ZIP_PATH" -d "$WORK_DIR/site"

for file in index.html manifest.webmanifest sw.js ENTWICKLER-QUELLCODE-v2.2.2.zip SHA256SUMS.txt; do
  test -f "$WORK_DIR/site/$file" || { echo "Pflichtdatei fehlt am ZIP-Stamm: $file" >&2; exit 1; }
done

if find "$WORK_DIR/site" -type f -path '*/.git/*' | grep -q .; then
  echo "Komplett-ZIP enthält unerwartet ein .git-Verzeichnis." >&2
  exit 1
fi
if find "$WORK_DIR/site" -type f -path '*/payload/*' | grep -q .; then
  echo "Komplett-ZIP enthält unerwartet ein payload-Verzeichnis." >&2
  exit 1
fi

(
  cd "$WORK_DIR/site"
  sha256sum -c SHA256SUMS.txt >/dev/null
  unzip -tq ENTWICKLER-QUELLCODE-v2.2.2.zip >/dev/null
)

node "$ROOT_DIR/scripts/verify-pages-build.mjs" "$WORK_DIR/site"
echo "Release-ZIP geprüft: $(basename "$ZIP_PATH")"
