#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ZIP_PATH="${1:?Aufruf: scripts/verify-pages-workflow.sh /pfad/kh-checker-v2.2.2-komplett.zip}"
ZIP_PATH="$(cd "$(dirname "$ZIP_PATH")" && pwd)/$(basename "$ZIP_PATH")"

for command in unzip rsync node find; do
  command -v "$command" >/dev/null 2>&1 || { echo "Benötigtes Werkzeug fehlt: $command" >&2; exit 1; }
done

WORK_DIR="$(mktemp -d)"
trap 'rm -rf "$WORK_DIR"' EXIT
mkdir -p "$WORK_DIR/site" "$WORK_DIR/unpacked"

unzip -tq "$ZIP_PATH" >/dev/null
unzip -q "$ZIP_PATH" -d "$WORK_DIR/unpacked"

# Keep this detector byte-for-byte equivalent in meaning to
# .github/workflows/deploy-pages.yml in karlokarate/kannalles1.
if [[ -f "$WORK_DIR/unpacked/index.html" ]]; then
  SOURCE_DIR="$WORK_DIR/unpacked"
else
  mapfile -t ROOTS < <(find "$WORK_DIR/unpacked" -mindepth 2 -maxdepth 2 -type f -name index.html | sort)
  if [[ ${#ROOTS[@]} -ne 1 ]]; then
    echo "Der Pages-Workflow würde das ZIP ablehnen: index.html muss am ZIP-Stamm oder in genau einem oberen Ordner liegen." >&2
    find "$WORK_DIR/unpacked" -type f -name index.html -print | sort >&2 || true
    exit 1
  fi
  SOURCE_DIR="$(dirname "${ROOTS[0]}")"
fi

rsync -a --delete "$SOURCE_DIR"/ "$WORK_DIR/site"/
touch "$WORK_DIR/site/.nojekyll"

test -f "$WORK_DIR/site/index.html"
test -f "$WORK_DIR/site/manifest.webmanifest"
test -f "$WORK_DIR/site/sw.js"

if find "$WORK_DIR/site" -type f -path '*/.git/*' | grep -q .; then
  echo "Der Pages-Workflow würde das ZIP wegen eines .git-Verzeichnisses ablehnen." >&2
  exit 1
fi
if find "$WORK_DIR/site" -type f -path '*/payload/*' | grep -q .; then
  echo "Der Pages-Workflow würde das ZIP wegen eines payload-Verzeichnisses ablehnen." >&2
  exit 1
fi

node "$ROOT_DIR/scripts/verify-pages-build.mjs" "$WORK_DIR/site"
node "$ROOT_DIR/scripts/verify-static-http.mjs" "$WORK_DIR/site"
FILE_COUNT="$(find "$WORK_DIR/site" -type f | wc -l | tr -d ' ')"
echo "Pages-Workflow-Emulation bestanden: index.html erkannt, $FILE_COUNT Dateien publishbar."
