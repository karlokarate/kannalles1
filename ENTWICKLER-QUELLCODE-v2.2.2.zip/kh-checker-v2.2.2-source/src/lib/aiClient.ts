import { z } from 'zod';
import type { ParsedFoodRequest } from '../types';
import { parseFoodRequestLocal } from './parser';

const AiResponseSchema = z.object({
  status: z.enum(['parsed', 'needs_clarification', 'unsupported']),
  rawInput: z.string(),
  product: z.object({
    name: z.string(),
    brand: z.string().nullable(),
    variant: z.string().nullable()
  }),
  amount: z.object({
    value: z.number().positive(),
    unit: z.enum(['g', 'kg', 'ml', 'piece', 'bar', 'slice', 'portion', 'package'])
  }),
  resolutionMode: z.enum(['generic_category', 'exact_product', 'barcode']),
  barcode: z.string().nullable(),
  clarificationQuestion: z.string().nullable(),
  parser: z.literal('openai')
});

export async function parseFoodRequestWithAi(
  rawInput: string,
  endpoint: string,
  signal?: AbortSignal
): Promise<ParsedFoodRequest> {
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ input: rawInput }),
    signal
  });

  if (!response.ok) {
    throw new Error(`OpenAI-Parser nicht verfügbar (${response.status}).`);
  }

  const parsed = AiResponseSchema.parse(await response.json());
  const localEvidence = parseFoodRequestLocal(rawInput);
  return {
    ...parsed,
    amount: {
      ...parsed.amount,
      valueExplicit: localEvidence.amount.valueExplicit,
      unitExplicit: localEvidence.amount.unitExplicit
    }
  };
}
