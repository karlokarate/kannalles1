# KH Checker v2.2.4 – hier starten

Dieses Paket ist die vollständige, generatorgetriebene v2.2.4-Integration für `karlokarate/kannalles1`.

## Empfohlen: lokaler One-Click-Installer

### Linux, macOS, WSL oder Git Bash

```bash
unzip KH-CHECKER-v2.2.4-ONE-CLICK-BUNDLE.zip
cd KH-CHECKER-v2.2.4-ONE-CLICK-BUNDLE
bash install-into-repo.sh /pfad/zu/deinem/kannalles1-checkout
```

### Windows PowerShell

```powershell
Expand-Archive .\KH-CHECKER-v2.2.4-ONE-CLICK-BUNDLE.zip
cd .\KH-CHECKER-v2.2.4-ONE-CLICK-BUNDLE
.\install-into-repo.ps1 -RepoPath C:\Pfad\zu\kannalles1
```

Danach im Repository:

```bash
git status --short
git add -A
git commit -m "release: KH Checker v2.2.4 generator-driven one-click deployment"
git push origin main
```

Anschließend auf GitHub nur noch:

1. **Actions** öffnen.
2. **Build, validate and deploy KH Checker v2.2.4** auswählen.
3. **Run workflow** drücken.

Der Workflow besitzt keine Eingaben und führt Generatoren, Validierungen, Release-Auswahl und GitHub-Pages-Deployment seriell aus.

> Den alten Workflow **Unpack KH Checker repo integration** nicht mehr starten. GitHub hatte dessen Push einer neuen Workflow-Datei wegen fehlender Workflow-Berechtigung des App-Tokens korrekt abgewiesen.

Ausführliche Hinweise: `INSTALLATION-v2.2.4.md`  
Prüfnachweise und bekannte Grenze: `VALIDATION-REPORT-v2.2.4.md`
