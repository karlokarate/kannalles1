# KH Checker v2.2.4 – One-Click-Workflow

- Deployment candidate: **validated-prebuilt-fallback**
- Release ZIP: `releases/kh-checker-v2.2.4-komplett.zip`
- SHA-256: `3d37d12084057098914b54f7331bfce99c54756151ec07f7757c416024f84abd`

| Gate | Ergebnis | Beschreibung |
|---|---|---|
| `fallback-validation` | passed | Hard-validated prebuilt v2.2.4 fallback |
| `npm-ci` | passed | Install locked dependencies |
| `api-generation` | passed | Regenerate and verify OpenAPI/Orval/Zod/MSW artifacts |
| `workflow-contract` | passed | Validate the single final workflow |
| `typecheck` | passed | Application TypeScript typecheck |
| `generated-typecheck` | passed | Generated Fetch/Zod/MSW/Faker TypeScript typecheck |
| `lint` | passed | Biome lint |
| `unit-contract-tests` | passed | Vitest unit and contract tests |
| `server-syntax` | passed | Optional gateway syntax |
| `scripts-syntax` | passed | Shell, Node and Python syntax |
| `audit` | passed | High/critical npm audit |
| `production-build` | passed | Vite/PWA production build |
| `pages-contract` | passed | GitHub Pages subpath/PWA validation |
| `playwright-install` | skipped | Browser installation explicitly skipped by ONE_CLICK_SKIP_BROWSER |
| `playwright-e2e` | skipped | Browser suite explicitly skipped; source candidate disqualified |
