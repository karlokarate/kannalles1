[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$RepoPath
)

$ErrorActionPreference = 'Stop'
$BundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Overlay = Join-Path $BundleRoot 'repo-overlay'
$ExpectedAppSha256 = '3d37d12084057098914b54f7331bfce99c54756151ec07f7757c416024f84abd'
$Target = (Resolve-Path -LiteralPath $RepoPath).Path

if (-not (Test-Path -LiteralPath (Join-Path $Target '.git') -PathType Container)) {
    throw "Ziel ist kein lokaler Git-Checkout: $Target"
}
if (-not (Test-Path -LiteralPath (Join-Path $Overlay 'package.json') -PathType Leaf)) {
    throw 'repo-overlay ist unvollständig.'
}

Write-Host "Installiere KH Checker v2.2.4 nach:`n  $Target`n"

$OldWorkflows = @(
    '.github/workflows/deploy-pages.yml',
    '.github/workflows/build-deploy-pages-v2.2.3.yml',
    '.github/workflows/unpack-kh-checker-repo-integration.yml'
)
foreach ($Relative in $OldWorkflows) {
    $Path = Join-Path $Target $Relative
    if (Test-Path -LiteralPath $Path) {
        Remove-Item -LiteralPath $Path -Force
        Write-Host "Entfernt: $Relative"
    }
}

# Copy-Item -Force übernimmt auch versteckte .github- und .gitignore-Dateien.
Get-ChildItem -LiteralPath $Overlay -Force | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $Target -Recurse -Force
}

$WorkflowDirectory = Join-Path $Target '.github/workflows'
$Workflows = @(Get-ChildItem -LiteralPath $WorkflowDirectory -File -Force | Where-Object { $_.Extension -in '.yml', '.yaml' })
$ExpectedWorkflow = Join-Path $WorkflowDirectory 'build-deploy-pages.yml'
if ($Workflows.Count -ne 1 -or -not (Test-Path -LiteralPath $ExpectedWorkflow -PathType Leaf)) {
    $Names = ($Workflows | ForEach-Object Name) -join ', '
    throw "Es muss genau build-deploy-pages.yml vorhanden sein. Gefunden: $Names"
}

$AppZip = Join-Path $Target 'releases/kh-checker-v2.2.4-komplett.zip'
$ActualAppSha256 = (Get-FileHash -LiteralPath $AppZip -Algorithm SHA256).Hash.ToLowerInvariant()
if ($ActualAppSha256 -ne $ExpectedAppSha256) {
    throw "SHA-256 des Release-ZIPs stimmt nicht: $ActualAppSha256"
}

$Python = Get-Command python3 -ErrorAction SilentlyContinue
if (-not $Python) { $Python = Get-Command py -ErrorAction SilentlyContinue }
if (-not $Python) { $Python = Get-Command python -ErrorAction SilentlyContinue }
if ($Python) {
    $TempSite = Join-Path ([System.IO.Path]::GetTempPath()) ("kh-v224-" + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $TempSite | Out-Null
    try {
        $Validator = Join-Path $Target '.github/scripts/validate_release_bundle.py'
        if ($Python.Name -eq 'py.exe' -or $Python.Name -eq 'py') {
            & $Python.Source -3 $Validator --zip $AppZip --site (Join-Path $TempSite 'site') --expected-version 2.2.4 --base-path /kannalles1/ | Out-Null
        } else {
            & $Python.Source $Validator --zip $AppZip --site (Join-Path $TempSite 'site') --expected-version 2.2.4 --base-path /kannalles1/ | Out-Null
        }
        if ($LASTEXITCODE -ne 0) { throw 'Release-ZIP-Validator ist fehlgeschlagen.' }
        Write-Host 'Release-ZIP: vollständig validiert.'
    } finally {
        Remove-Item -LiteralPath $TempSite -Recurse -Force -ErrorAction SilentlyContinue
    }
} else {
    Write-Warning 'Python 3 fehlt; die vollständige ZIP-Prüfung übernimmt der finale GitHub-Workflow.'
}

Write-Host "`nInstallation abgeschlossen. Es wurde nichts committed oder gepusht.`n"
Write-Host 'Nächste Befehle:'
Write-Host "  cd `"$Target`""
Write-Host '  git status --short'
Write-Host '  git add -A'
Write-Host '  git commit -m "release: KH Checker v2.2.4 generator-driven one-click deployment"'
Write-Host '  git push origin main'
Write-Host "`nDanach in GitHub Actions starten: Build, validate and deploy KH Checker v2.2.4"
