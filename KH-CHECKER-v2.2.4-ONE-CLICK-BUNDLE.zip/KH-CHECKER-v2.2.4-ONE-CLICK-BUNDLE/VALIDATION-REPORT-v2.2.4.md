# Validierungsbericht – KH Checker v2.2.4

## Freigabegegenstand

- App/PWA: `kh-checker-v2.2.4-komplett.zip`
- Entwicklerquelle: `ENTWICKLER-QUELLCODE-v2.2.4.zip`
- Repository-Overlay: `KH-CHECKER-v2.2.4-REPO-OVERLAY.zip`
- Finaler Workflow: `.github/workflows/build-deploy-pages.yml`
- Zentrale API-Quelle: `contracts/source/search-api.contract.mjs`
- Ziel: statische, repository-subpath-sichere GitHub-Pages-PWA

## Generatorstrecke

Aus einer Hono/Zod/OpenAPI-Routendefinition werden deterministisch erzeugt:

- OpenAPI 3.1 JSON und YAML,
- typisierte Fetch-Funktionen und URL-Builder,
- TypeScript-Modelle,
- Zod-Laufzeitvalidatoren,
- MSW-Handler,
- Faker-Factories,
- Browser- und Express-Adapter,
- API-Dokumentation,
- Contract-Tests,
- ein SHA-256-basiertes Generationsmanifest.

Die Browser-App und der optionale Express-Gateway verwenden die generierten Zod-Verträge für Suche, Produktdetails und AI-Parser-Antworten. Cache, Fallback, Deduplizierung, Ranking, Einheitenauflösung, Kalibrierung und KH-Berechnung bleiben bewusst projektspezifische Fachlogik.

## Erfolgreich ausgeführte Prüfungen

| Bereich | Ergebnis |
|---|---|
| Gelockte Installation mit `npm ci --no-audit --no-fund` | bestanden |
| Hono/Zod → OpenAPI 3.1 | bestanden |
| Redocly-Lint | bestanden |
| Orval Fetch/Modelle/Zod/MSW/Faker | bestanden |
| Generator-Hash-/Driftprüfung | bestanden |
| Genau ein manueller finaler Workflow | bestanden |
| App-TypeScript | bestanden |
| Generierter TypeScript-Code | bestanden |
| Biome | bestanden |
| Vitest/Contract-Tests | **9 Dateien, 82 Tests bestanden** |
| Optionaler Express-Gateway-Syntaxcheck | bestanden |
| Shell-/Node-/Python-Syntax | bestanden |
| Vite 8/PWA-Produktionsbuild | bestanden |
| PWA-Precache | **22 Einträge** |
| GitHub-Pages-Unterpfade und Pflichtdateien | bestanden |
| Statische HTTP-Auslieferung | bestanden |
| npm audit | **0 total, 0 high, 0 critical** |
| Vollständige SHA-256-Abdeckung des App-ZIPs | bestanden |
| Zwei unabhängige deterministische Release-Builds | byteidentisch |
| Bash-Installer in frischem Git-Repository | bestanden |
| Entfernung der drei Alt-Workflows | bestanden |
| Workflowvertrag nach Installation | bestanden |
| Failsoft-Auswahl des vorvalidierten Fallbacks | bestanden |

## Negative Sicherheitstests

Der Release-Validator hat erwartungsgemäß abgelehnt:

1. nachträglich manipulierte `index.html` mit unverändertem `SHA256SUMS.txt`,
2. ZIP-Eintrag `../escape.txt`,
3. zusätzliches `tool.jar` trotz neu berechneter Checksummen.

Die zugehörigen Logs liegen unter `validation-evidence/negative-validator/`.

## Reproduzierbare Hauptartefakte

```text
ca34829f81e62646c4c3ad9ea022bc79c5fafbddf25904eef6ade7e83fb6c084  ENTWICKLER-QUELLCODE-v2.2.4.zip
3d37d12084057098914b54f7331bfce99c54756151ec07f7757c416024f84abd  kh-checker-v2.2.4-komplett.zip
```

Beide Hashes wurden in zwei vollständig getrennten Builds identisch erzeugt.

## Abhängigkeits- und Supply-Chain-Fixes

- alle `resolved`-Einträge im npm-Lockfile zeigen auf die öffentliche npm-Registry,
- keine dynamische Erstellung eines ungesperrten Testprojekts im Release-ZIP-Pfad,
- Generator-, Test- und Browsermodule sind im Lockfile festgelegt,
- das Deploy-Artefakt enthält weder Node.js noch Entwicklungsabhängigkeiten, JAR/AAR, Servercode, Datenbank oder Produktdatensatz,
- das finale Pages-/OIDC-Deployment besitzt nur die dafür notwendigen Rechte.

## Browser-Grenze dieser lokalen Prüfung

Die Playwright-Suite und ihre Assertions sind enthalten. Sie deckt Chromium-Desktop, Android-Viewport, WebKit/iPhone, PWA/Service Worker, Offline-Neuladen, den tatsächlich neu ausgelösten manuellen Retry, das Zwei-Backend-Budget und einen axe-WCAG-A/AA-Smoke ab.

In dieser isolierten Ausführungsumgebung wurde die vollständige echte Browser-Suite nicht abschließend ausgeführt. Der GitHub-Workflow installiert Chromium und WebKit und versucht sie dort. Ein reiner Browser-Infrastrukturfehler führt failsoft zum bereits hart validierten App-ZIP; ein unsicheres oder unvollständiges App-Artefakt kann dagegen niemals veröffentlicht werden.

## Nicht durchgeführt

- kein Commit oder Push in das Benutzer-Repository,
- kein tatsächlicher GitHub-Pages-Deploy,
- keine Umgehung der GitHub-Berechtigungsgrenze für Workflow-Dateien.

Diese Schritte bleiben bewusst beim Repository-Eigentümer: Overlay kopieren, normal committen/pushen und den einen finalen Workflow starten.
