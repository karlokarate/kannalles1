# Installation und Deployment – KH Checker v2.2.4

## 1. Was installiert wird

`repo-overlay/` enthält den vollständigen v2.2.4-Quellstand, die normative Contract-Basis, erzeugte API-Artefakte, den sicheren Release-Validator und genau einen finalen Workflow:

```text
.github/workflows/build-deploy-pages.yml
```

Zusätzlich liegt das hart vorvalidierte Failsoft-Artefakt an seiner endgültigen Position:

```text
releases/kh-checker-v2.2.4-komplett.zip
```

Der Installer entfernt gezielt diese drei konkurrierenden Alt-Workflows, sofern vorhanden:

```text
.github/workflows/deploy-pages.yml
.github/workflows/build-deploy-pages-v2.2.3.yml
.github/workflows/unpack-kh-checker-repo-integration.yml
```

Andere Dateien und ältere Release-ZIPs werden nicht pauschal gelöscht.

## 2. Vorbereitung

Benötigt wird ein lokaler Checkout von:

```text
https://github.com/karlokarate/kannalles1
```

Beispiel:

```bash
git clone https://github.com/karlokarate/kannalles1.git
```

Für den späteren Push muss dein lokales Git-Konto Workflow-Dateien unter `.github/workflows/` aktualisieren dürfen. Der frühere GitHub-App-Installationslauf scheiterte genau an dieser Berechtigungsgrenze. Nutze daher deinen normalen GitHub-Account, GitHub Desktop, SSH oder einen Token mit den dafür erforderlichen Rechten.

## 3. Overlay installieren

### Linux/macOS/WSL/Git Bash

```bash
bash install-into-repo.sh /vollständiger/pfad/kannalles1
```

### Windows

```powershell
.\install-into-repo.ps1 -RepoPath C:\vollständiger\Pfad\kannalles1
```

Alternativ funktioniert `install-into-repo.cmd` aus der Eingabeaufforderung.

Der Installer:

- verlangt einen echten Git-Checkout,
- entfernt nur die bekannten alten KH-Checker-Workflows,
- kopiert auch versteckte Dateien wie `.github` und `.gitignore`,
- fordert genau einen finalen Workflow,
- prüft den SHA-256-Hash des App-ZIPs,
- führt bei vorhandenem Python 3 den vollständigen sicheren Release-Validator aus,
- führt weder Commit noch Push aus.

## 4. Änderungen prüfen und pushen

```bash
cd /vollständiger/pfad/kannalles1
git status --short
git add -A
git commit -m "release: KH Checker v2.2.4 generator-driven one-click deployment"
git push origin main
```

Vor dem Commit sollte unter `.github/workflows/` ausschließlich diese Datei liegen:

```text
build-deploy-pages.yml
```

## 5. GitHub Pages einmalig prüfen

Im Repository:

1. **Settings → Pages** öffnen.
2. Unter **Build and deployment** als Quelle **GitHub Actions** verwenden.
3. Im Environment `github-pages` keine Required Reviewers und keinen Wait Timer konfigurieren, wenn der Ablauf ungated bleiben soll.

Für den normalen direkten Browserbetrieb sind keine Variablen erforderlich. Optional erlaubt sind öffentliche Build-Variablen:

```text
VITE_DATA_GATEWAY_URL
VITE_AI_PARSE_URL
```

Keine API-Schlüssel oder sonstigen Geheimnisse in `VITE_*` ablegen, weil diese Werte in der Web-App öffentlich werden.

## 6. Einen einzigen finalen Workflow starten

1. **Actions** öffnen.
2. **Build, validate and deploy KH Checker v2.2.4** auswählen.
3. **Run workflow** drücken.
4. Branch `main` wählen.
5. Start bestätigen.

Es gibt keine weiteren Inputs und keinen zweiten Integrationsworkflow.

## 7. Was der Workflow seriell erledigt

```text
vorvalidiertes v2.2.4-App-ZIP
→ sichere ZIP-/SHA-256-/PWA-Prüfung
→ npm ci aus festem Lockfile
→ Hono/Zod-Contract → OpenAPI 3.1
→ Redocly-Lint und statische API-Dokumentation
→ Orval Fetch + TypeScript-Modelle + Zod + MSW + Faker
→ Generator-Hash- und Driftprüfung
→ Workflowvertrag
→ TypeScript und generierter TypeScript-Code
→ Biome
→ Vitest- und Contract-Tests
→ Server-/Shell-/Node-/Python-Syntax
→ npm audit
→ Vite/PWA-Build und Pages-Unterpfadprüfung
→ Playwright Chromium/WebKit, mobile Viewports, Offline, Retry und axe
→ deterministische Release-ZIPs
→ erneute ZIP-/HTTP-/Pages-Prüfung
→ Auswahl: vollständiger Source-Build oder validiertes Fallback
→ Pages-Artefakt
→ OIDC-Deployment nach github-pages
```

## 8. Failsoft-Verhalten

Folgende Störungen disqualifizieren nur den neuen Quellkandidaten; die vorvalidierte PWA bleibt deploybar:

- npm-Registry oder Browserdownload vorübergehend nicht erreichbar,
- Generator-, Lint-, Test-, Audit- oder Buildstörung,
- Playwright-Infrastruktur nicht verfügbar.

Harte Abbrüche bleiben absichtlich:

- korruptes, manipuliertes oder unsicheres Release-ZIP,
- `../`-Traversal, Symlink, Sonderdatei, Verschlüsselung oder Zip-Bomb-Muster,
- unvollständige oder falsche SHA-256-Abdeckung,
- fehlende PWA-Pflichtdateien,
- JAR/AAR/APK/AAB/WAR, Datenbank-, Server- oder private Schlüsseldateien im Web-Artefakt,
- ungültige GitHub-Pages-Pfade,
- fehlgeschlagener finaler Artefakt-Upload oder Pages-Deploy.

## 9. Nach dem Deployment

Die veröffentlichte Adresse erscheint im Workflow Summary sowie unter:

```text
Deployments → github-pages
```

Die PWA kann danach installiert werden:

- iPhone/iPad: Safari → Teilen → Zum Home-Bildschirm
- Android: Chrome → App installieren
- Desktop: Installationssymbol des PWA-fähigen Browsers

## 10. Manuelle Alternative

Ohne Installer kann der Inhalt von `repo-overlay/` direkt in den Repository-Stamm kopiert werden. Danach dieselben drei Alt-Workflows löschen, committen, pushen und den finalen Workflow starten.

Das eigenständige Overlay-ZIP liegt unter:

```text
artifacts/KH-CHECKER-v2.2.4-REPO-OVERLAY.zip
```
