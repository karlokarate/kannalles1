#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
if command -v sha256sum >/dev/null 2>&1; then
  sha256sum -c FULL-BUNDLE.SHA256SUMS.txt
elif command -v shasum >/dev/null 2>&1; then
  shasum -a 256 -c FULL-BUNDLE.SHA256SUMS.txt
else
  echo 'Weder sha256sum noch shasum ist verfügbar.' >&2
  exit 1
fi
