$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ChecksumFile = Join-Path $Root 'FULL-BUNDLE.SHA256SUMS.txt'
foreach ($Line in Get-Content -LiteralPath $ChecksumFile) {
    if ([string]::IsNullOrWhiteSpace($Line)) { continue }
    if ($Line -notmatch '^([0-9a-f]{64})  (.+)$') { throw "Ungültige Prüfsummenzeile: $Line" }
    $Expected = $Matches[1]
    $Relative = $Matches[2].Replace('/', [IO.Path]::DirectorySeparatorChar)
    $Path = Join-Path $Root $Relative
    $Actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Actual -ne $Expected) { throw "SHA-256 stimmt nicht: $Relative" }
    Write-Host "OK  $Relative"
}
