# KH Checker v2.2.4 One-Click Bundle

Beginne mit [`00-START-HIER.md`](00-START-HIER.md).

Dieses Paket enthält das vollständige Repository-Overlay, die reproduzierbaren App-/Source-ZIPs, Installer für Linux/macOS/Windows, den finalen GitHub-Pages-Workflow, generierte OpenAPI-Artefakte sowie Validierungsnachweise.
