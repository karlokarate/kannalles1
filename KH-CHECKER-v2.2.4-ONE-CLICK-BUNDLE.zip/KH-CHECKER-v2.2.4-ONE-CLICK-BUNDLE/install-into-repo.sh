#!/usr/bin/env bash
set -euo pipefail

BUNDLE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OVERLAY="$BUNDLE_ROOT/repo-overlay"
EXPECTED_APP_SHA256="3d37d12084057098914b54f7331bfce99c54756151ec07f7757c416024f84abd"

fail() {
  printf 'FEHLER: %s\n' "$*" >&2
  exit 1
}

if [[ $# -ne 1 ]]; then
  cat >&2 <<USAGE
Verwendung:
  bash install-into-repo.sh /pfad/zum/kannalles1-repository
USAGE
  exit 2
fi

TARGET="$(cd "$1" 2>/dev/null && pwd)" || fail "Repository-Pfad existiert nicht: $1"
[[ -d "$TARGET/.git" ]] || fail "Ziel ist kein lokaler Git-Checkout: $TARGET"
[[ -f "$OVERLAY/package.json" ]] || fail "repo-overlay ist unvollständig."
[[ -f "$OVERLAY/releases/kh-checker-v2.2.4-komplett.zip" ]] || fail "v2.2.4-Fallback-ZIP fehlt."

printf 'Installiere KH Checker v2.2.4 nach:\n  %s\n\n' "$TARGET"

# Nur die bekannten konkurrierenden KH-Checker-Workflows entfernen.
for relative in \
  .github/workflows/deploy-pages.yml \
  .github/workflows/build-deploy-pages-v2.2.3.yml \
  .github/workflows/unpack-kh-checker-repo-integration.yml
do
  if [[ -e "$TARGET/$relative" ]]; then
    rm -f -- "$TARGET/$relative"
    printf 'Entfernt: %s\n' "$relative"
  fi
done

# tar erhält versteckte Dateien und funktioniert unter Linux/macOS/WSL/Git Bash.
(
  cd "$OVERLAY"
  tar -cf - .
) | (
  cd "$TARGET"
  tar -xf -
)

WORKFLOW_LIST="$(find "$TARGET/.github/workflows" -maxdepth 1 -type f \( -name '*.yml' -o -name '*.yaml' \) -print | sort)"
WORKFLOW_COUNT="$(printf '%s\n' "$WORKFLOW_LIST" | sed '/^$/d' | wc -l | tr -d '[:space:]')"
if [[ "$WORKFLOW_COUNT" != "1" ]] || [[ ! -f "$TARGET/.github/workflows/build-deploy-pages.yml" ]]; then
  printf 'Gefundene Workflows:\n%s\n' "$WORKFLOW_LIST" >&2
  fail "Nach der Installation muss genau .github/workflows/build-deploy-pages.yml vorhanden sein."
fi

APP_ZIP="$TARGET/releases/kh-checker-v2.2.4-komplett.zip"
if command -v sha256sum >/dev/null 2>&1; then
  ACTUAL_APP_SHA256="$(sha256sum "$APP_ZIP" | awk '{print $1}')"
elif command -v shasum >/dev/null 2>&1; then
  ACTUAL_APP_SHA256="$(shasum -a 256 "$APP_ZIP" | awk '{print $1}')"
else
  fail "Weder sha256sum noch shasum ist verfügbar."
fi
[[ "$ACTUAL_APP_SHA256" == "$EXPECTED_APP_SHA256" ]] || fail "SHA-256 des Release-ZIPs stimmt nicht."

if command -v python3 >/dev/null 2>&1; then
  TMP_SITE="$(mktemp -d)"
  trap 'rm -rf "$TMP_SITE"' EXIT
  python3 "$TARGET/.github/scripts/validate_release_bundle.py" \
    --zip "$APP_ZIP" \
    --site "$TMP_SITE/site" \
    --expected-version 2.2.4 \
    --base-path /kannalles1/ >/dev/null
  printf 'Release-ZIP: vollständig validiert.\n'
else
  printf 'HINWEIS: python3 fehlt; die vollständige ZIP-Prüfung übernimmt der finale GitHub-Workflow.\n'
fi

printf '\nInstallation abgeschlossen. Es wurde nichts committed oder gepusht.\n\n'
printf 'Nächste Befehle:\n'
printf '  cd %q\n' "$TARGET"
printf '  git status --short\n'
printf '  git add -A\n'
printf '  git commit -m %q\n' 'release: KH Checker v2.2.4 generator-driven one-click deployment'
printf '  git push origin main\n\n'
printf 'Danach in GitHub Actions genau diesen Workflow starten:\n'
printf '  Build, validate and deploy KH Checker v2.2.4\n'
