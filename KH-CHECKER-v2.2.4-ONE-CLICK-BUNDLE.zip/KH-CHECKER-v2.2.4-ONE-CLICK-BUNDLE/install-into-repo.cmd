@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-into-repo.ps1" %*
exit /b %ERRORLEVEL%
