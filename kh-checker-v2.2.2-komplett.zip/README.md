# KH Checker v2.2.2

KH Checker ist eine installierbare, statische Progressive Web App für iPhone, iPad, Android und Desktop. GitHub Pages stellt ausschließlich die fertigen Web-Dateien bereit. Produktsuche, Cache, Produktauflösung, Kalibrierungen und Kohlenhydratberechnung laufen auf dem jeweiligen Gerät; für den normalen Betrieb ist kein eigener Server erforderlich.

## Zielbetrieb

```text
GitHub Pages
└── statische PWA
    ├── Service Worker und App-Shell-Cache
    ├── IndexedDB/localStorage
    ├── lokale Such-, Ranking- und Berechnungslogik
    └── direkte HTTPS-Abfragen
        ├── Search-a-licious (Primärsuche)
        ├── OFF Legacy Search (genau ein Fallback)
        ├── OFF API v3.6 (Produktdetails)
        └── OFF API v2 (nur bei weiterhin fehlenden Nährwerten)
```

Die optionale Gateway-Einstellung bleibt für bestehende Sonderdeployments erhalten. Sie ist weder für GitHub Pages noch für eine installierte PWA erforderlich und wird nicht automatisch erkannt oder abgefragt.

## Änderungen in v2.2.2

### Pages-first-Suchpfad

Die App verwendet nun in jeder HTTPS-Browser- und PWA-Laufzeit dieselbe deterministische Reihenfolge:

1. Suchtext bereinigen, Tippfehler korrigieren und kanonisieren.
2. Frischen backend-unabhängigen Suchcache prüfen.
3. Migrierbaren URL-Cache älterer Releases prüfen.
4. Search-a-licious genau einmal aufrufen.
5. OFF Legacy Search genau einmal aufrufen, wenn der Primärweg technisch scheitert **oder null Treffer liefert**.
6. Erst wenn beide öffentlichen Backends technisch scheitern, vorhandene Reserve-Daten verwenden.
7. Andernfalls einen typisierten Leer- oder Fehlerzustand an die Oberfläche geben.

Damit bleibt die Anzahl realer Suchrequests pro Benutzeraktion auf höchstens zwei begrenzt. Es gibt keine Suche während des Tippens, keinen lokalen Cooldown und keinen lokalen Request-Zähler, der einen Retry sperrt.

### Korrekte Fallback- und Cache-Semantik

- Search-a-licious ist wieder der Primärweg.
- Eine gültige Null-Treffer-Antwort löst den vertraglich vorgesehenen zweiten Suchweg aus.
- Ein veralteter URL-Cache darf den zweiten Backend-Versuch nicht mehr vorzeitig unterdrücken.
- Stale Search Cache wird erst verwendet, nachdem beide öffentlichen Suchbackends fehlgeschlagen sind oder das Gerät nachweislich offline ist.
- Gleichwertige Schreibweisen verwenden denselben kanonischen Cache-Schlüssel.
- Identische parallele GET-Requests teilen denselben In-Flight-Task.
- Ein sofortiger manueller Retry bleibt möglich.

### Produktdetails ohne unnötige Fan-outs

Nur der ausgewählte Treffer wird über seinen Barcode hydratisiert. OFF API v3.6 ist primär. Bereits im Suchtreffer enthaltene Kohlenhydratwerte werden als Seed übernommen. Der v2-Kompatibilitätsendpunkt wird nur verwendet, wenn nach dem Zusammenführen weiterhin notwendige Kohlenhydratdaten fehlen.

Ein Produktdetailabruf überschreibt die Diagnose der vorherigen Produktsuche nicht. Alle Versuche bleiben in einer gemeinsamen, kopierbaren Ablaufspur sichtbar.

### GitHub-Pages-kompatibles Release

Das Komplett-ZIP enthält die gebaute PWA direkt im ZIP-Stamm:

```text
index.html
manifest.webmanifest
sw.js
workbox-*.js
assets/
icons/
```

Damit erfüllt es den vorhandenen Workflow `.github/workflows/deploy-pages.yml`, der `index.html` am ZIP-Stamm oder in genau einem oberen Ordner erwartet. Alle App-, Manifest- und Icon-Pfade sind relativ, sodass die PWA auch unter dem Repository-Unterpfad von GitHub Pages funktioniert.

## Deployment mit dem vorhandenen GitHub-Workflow

1. `kh-checker-v2.2.2-komplett.zip` unverändert nach `releases/kh-checker-v2.2.2-komplett.zip` im Repository hochladen.
2. Unter **Actions** den Workflow **Deploy selected KH Checker ZIP to GitHub Pages** starten.
3. Als `zip_path` exakt `releases/kh-checker-v2.2.2-komplett.zip` eintragen.
4. Nach erfolgreichem Deployment die vom Workflow ausgegebene Pages-Adresse öffnen.

Die ZIP muss nicht vorher entpackt oder neu gepackt werden.

## Installation auf Geräten

### iPhone und iPad

Die GitHub-Pages-Seite in Safari öffnen, **Teilen** wählen und anschließend **Zum Home-Bildschirm**. Die installierte App behält die HTTPS-Origin der Pages-Seite und nutzt dieselben direkten API-Wege.

### Android

Die Pages-Seite in Chrome öffnen und **App installieren** beziehungsweise **Zum Startbildschirm hinzufügen** wählen.

### Windows, macOS und Linux

Die Pages-Seite in einem PWA-fähigen Chromium-Browser öffnen und das Installationssymbol in der Adressleiste verwenden. Safari auf macOS kann die Seite ebenfalls als Web-App hinzufügen.

Ein direktes Öffnen von `index.html` über `file://` ist nicht der Produktionsweg: Service Worker benötigen einen sicheren HTTP(S)-Kontext. GitHub Pages stellt diesen Kontext bereit.

## Cache und Offline-Verhalten

| Daten | Frisch | Ausfallreserve |
|---|---:|---:|
| erfolgreiche Suche | 24 Stunden | 30 Tage |
| leere Suche | 15 Minuten | 24 Stunden |
| Produktdetails | 30 Tage | 180 Tage |

Der Service Worker cached App-Shell und Produktbilder. API-JSON wird bewusst vom Request Manager verwaltet, damit Fresh-/Stale-Zustand und Fehlerdiagnose eindeutig bleiben. Bereits gespeicherte Produkte und Berechnungen bleiben offline nutzbar; eine globale neue OFF-Suche benötigt weiterhin eine Netzwerkverbindung.

## Deterministische Mengenauflösung

- explizite Nutzer-Einheiten bleiben erhalten
- bewiesene Einzelgewichte stehen vor Portion und Packung
- Stückgewicht kann aus expliziter Stückzahl und Nettogewicht abgeleitet werden
- unbekannte zählbare Einheiten führen zur Kalibrierung statt zu einer Schätzung
- Einzel- und Gruppenwägung werden lokal produktbezogen gespeichert
- Kohlenhydrate werden stets aus aktuellem `carbohydratesPer100g` und gespeichertem Gewicht neu berechnet
- intern wird nicht vor dem Endergebnis gerundet

## Entwicklung

Voraussetzung: Node.js 22.12 oder neuer.

```bash
npm ci
npm run check
```

Einzelne Prüfungen:

```bash
npm run typecheck
npm run lint
npm test
npm run check:server
npm run build
npm run check:pages
# nach npm run release:
npm run check:release
```

`npm run check:pages` verifiziert nach dem Build Pflichtdateien, relative Unterpfade, Manifest-Scope, Start-URL und App-Icons.

Für die lokale UI-Entwicklung:

```bash
npm run dev
```

Der Express-Server unter `server/index.mjs` ist nur noch ein optionaler Kompatibilitäts- und KI-Parser-Host. Er gehört nicht zum notwendigen GitHub-Pages-Laufzeitpfad.

## Qualität und nächste Ausbaustufe

Der Release-Gate umfasst TypeScript, Biome, Vitest, Server-Syntax, Vite/PWA-Produktionsbuild, Pages-Unterpfadprüfung, exakte Workflow-Paketemulation, statische HTTP-Auslieferung und ZIP-Prüfung. Sinnvolle externe Ergänzungen sind Playwright mit realen WebKit-/Chromium-Projekten, Lighthouse CI, axe-core, Sentry sowie Renovate oder Dependabot. Vor einem späteren Modul-Upgrade sollten insbesondere Vite, vite-plugin-pwa, React, TypeScript und Biome gemeinsam in einer separaten Dependency-Wave aktualisiert und gegen iOS-PWA-Caching getestet werden, statt sie unkontrolliert in einen Funktionsfix zu mischen.

## Grenzen

Die App kann externe Dienste nicht verfügbar machen, wenn Open Food Facts oder das Netz des Geräts ausfallen. In diesem Fall liefert sie einen typisierten temporären Fehler oder vorhandene Reserve-Daten und erlaubt den sofortigen Retry. Eine vollständige weltweite Produktsuche kann nicht rein offline auf dem Gerät erfolgen, weil der globale OFF-Suchindex nicht Bestandteil der App ist.
