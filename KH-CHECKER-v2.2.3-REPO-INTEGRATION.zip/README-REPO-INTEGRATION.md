# KH Checker v2.2.3 – Repository-Integration

Diese Dateien einmal in den Stamm von `karlokarate/kannalles1` übernehmen.

## Enthalten

- `.github/workflows/build-deploy-pages.yml`
- `.github/scripts/validate_release_bundle.py`
- `.github/e2e/release.spec.ts`
- `.github/e2e/playwright.release.config.ts`
- `.github/dependabot.yml`

## Empfohlener bestehender Release-ZIP-Weg

1. `kh-checker-v2.2.3-komplett.zip` unverändert nach `releases/kh-checker-v2.2.3-komplett.zip` hochladen.
2. Wenn bei einem Push genau ein neues `releases/*.zip` geändert wurde, erkennt der Workflow es automatisch.
3. Alternativ manuell starten:
   - `mode`: `release_zip`
   - `zip_path`: `releases/kh-checker-v2.2.3-komplett.zip`
4. Der Workflow validiert ZIP-Sicherheit, Prüfsummen, Manifest, Service Worker, relative Pages-Pfade, API-Pfade und Secrets.
5. Vor dem Deploy werden Chromium Desktop, Android-Viewport, WebKit/iPhone, Offline-App-Shell und axe WCAG A/AA geprüft.

## Optionaler Source-Build

Liegt der vollständige v2.2.3-Quellcode im Repository-Stamm, kann `mode=source` verwendet werden. Dann führt der Workflow `npm ci`, alle Unit-/Type-/Lint-/PWA-Gates und den Release-Build aus, lädt beide erzeugten ZIPs als Actions-Artefakt hoch und deployt erst nach den Browser-Gates.

## Öffentliche Build-Variablen

Optional unter **Settings → Secrets and variables → Actions → Variables** anlegen:

- `VITE_DATA_GATEWAY_URL`
- `VITE_AI_PARSE_URL`

Diese Werte werden in öffentliches Browser-JavaScript eingebettet und dürfen keine Geheimnisse enthalten. `OFF_USER_AGENT` und `OPENAI_API_KEY` gehören ausschließlich auf einen optionalen Server und nicht in diesen Pages-Workflow.
