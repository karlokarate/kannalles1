# KH Checker v2.2.3

KH Checker ist eine installierbare, statische Progressive Web App für iPhone, iPad, Android und Desktop. GitHub Pages stellt ausschließlich die fertigen Web-Dateien bereit. Produktsuche, Cache, Produktauflösung, Kalibrierungen und Kohlenhydratberechnung laufen auf dem jeweiligen Gerät; für den normalen Betrieb ist kein eigener Server erforderlich.

## Zielbetrieb

```text
GitHub Pages
└── statische PWA
    ├── Service Worker und App-Shell-Cache
    ├── IndexedDB/localStorage
    ├── lokale Such-, Ranking- und Berechnungslogik
    └── direkte HTTPS-Abfragen
        ├── Search-a-licious (Primärsuche)
        ├── OFF Legacy Search (genau ein Fallback)
        ├── OFF API v3.6 (Produktdetails)
        └── OFF API v2 (nur bei weiterhin fehlenden Nährwerten)
```

Die optionale Gateway-Einstellung bleibt für bestehende Sonderdeployments erhalten. Sie ist weder für GitHub Pages noch für eine installierte PWA erforderlich und wird nicht automatisch erkannt oder abgefragt.

## Änderungen in v2.2.3

### Reproduzierbarer Build und sicherer Pages-Deploy

- App-, Server-, Workbox- und Release-Version werden aus `package.json` abgeleitet oder im Gate gegengeprüft.
- Der Workflow unterstützt zwei contractkonforme Wege: Quellcode im Repository bauen oder ein bereits lokal erzeugtes `releases/*.zip` validieren und deployen.
- Build/Tests laufen ohne Pages-Schreibrechte. Nur der separate Deploy-Job erhält `pages: write` und `id-token: write`.
- Bereits laufende Produktionsdeployments werden nicht abgebrochen.
- `VITE_DATA_GATEWAY_URL` und `VITE_AI_PARSE_URL` sind optionale, öffentliche Repository-Variablen. Sie werden nie als Geheimnisse behandelt.
- `OFF_USER_AGENT` verbleibt ausschließlich im optionalen Node-Gateway und wird nicht wirkungslos in Browser-JavaScript injiziert.

### PWA- und Paket-Fixes

- Apple-Touch-Icon, Begleitseiten und Diagnosewerkzeug sind verbindlich im App-Shell-Precache.
- `navigateFallbackDenylist`, relative GitHub-Pages-Pfade und `purgeOnQuotaError` bleiben erhalten.
- Der statische Standardbuild enthält keinen nicht vorhandenen relativen AI-Endpunkt.
- CSP- und Referrer-Metadaten härten die statische Pages-Auslieferung.
- Das deploybare Komplett-ZIP enthält keine Quellcodeordner, `node_modules`, verschachtelten ZIPs oder Secrets. Der Entwickler-Quellcode wird separat ausgegeben.

### Browser-, UX- und Accessibility-Gates

- Chromium-Desktop, Android-Viewport und WebKit-iPhone werden mit Playwright geprüft.
- axe-core prüft die Startansicht auf WCAG-A/AA-Verstöße.
- Eine deterministische manuelle KH-Berechnung wird vollständig ohne Netzwerk getestet.
- Der Suchbutton muss während einer laufenden Anfrage sofort erneut bedienbar bleiben.
- Service-Worker-Registrierung, Offline-Neuladen, Manifest, Icons, mobile Breite und Hauptnavigation werden geprüft.

### API- und Berechnungsvertrag bleibt erhalten

- Search-a-licious ist Primärsuche; OFF Legacy folgt höchstens einmal nach technischem Fehler oder null Treffern.
- Cache wird vor Netzwerk geprüft; Stale-Daten werden nur bei Offlinezustand oder nach Backendfehlern verwendet.
- Nur das ausgewählte Produkt wird über OFF API v3.6 hydratisiert; v2 ergänzt nur weiterhin fehlende Nährwerte.
- Unbekannte Einzelgewichte führen zur Einzel- oder Gruppenwägung statt zu einer Schätzung.

## Release-Artefakte

`npm run release` erzeugt getrennt:

```text
release-out/kh-checker-v2.2.3-komplett.zip
release-out/ENTWICKLER-QUELLCODE-v2.2.3.zip
```

Das Komplett-ZIP enthält die gebaute PWA direkt im ZIP-Stamm und ist das einzige ZIP, das nach `releases/` hochgeladen und von GitHub Pages deployt wird. Das Quellcode-ZIP wird nicht in das Pages-Artefakt eingebettet.

## Deployment mit dem v2.2.3-Workflow

1. Die Dateien aus `KH-CHECKER-v2.2.3-REPO-INTEGRATION.zip` einmal in den Repository-Stamm übernehmen.
2. `kh-checker-v2.2.3-komplett.zip` unverändert als `releases/kh-checker-v2.2.3-komplett.zip` hochladen.
3. Der Push deployt genau dieses neu geänderte ZIP automatisch. Alternativ den Workflow **Build, validate and deploy KH Checker PWA** manuell mit `mode=release_zip` starten.
4. Befindet sich der vollständige Quellcode im Repository-Stamm, kann `mode=source` die PWA bauen, alle Gates ausführen, die beiden Release-ZIPs als Actions-Artefakt ausgeben und anschließend deployen.

Die ZIP wird sicher entpackt, vollständig per SHA-256 geprüft und unter dem Repository-Unterpfad per lokalem HTTP-Smoke getestet.

## Installation auf Geräten

### iPhone und iPad

Die GitHub-Pages-Seite in Safari öffnen, **Teilen** wählen und anschließend **Zum Home-Bildschirm**. Die installierte App behält die HTTPS-Origin der Pages-Seite und nutzt dieselben direkten API-Wege.

### Android

Die Pages-Seite in Chrome öffnen und **App installieren** beziehungsweise **Zum Startbildschirm hinzufügen** wählen.

### Windows, macOS und Linux

Die Pages-Seite in einem PWA-fähigen Chromium-Browser öffnen und das Installationssymbol in der Adressleiste verwenden. Safari auf macOS kann die Seite ebenfalls als Web-App hinzufügen.

Ein direktes Öffnen von `index.html` über `file://` ist nicht der Produktionsweg: Service Worker benötigen einen sicheren HTTP(S)-Kontext. GitHub Pages stellt diesen Kontext bereit.

## Cache und Offline-Verhalten

| Daten | Frisch | Ausfallreserve |
|---|---:|---:|
| erfolgreiche Suche | 24 Stunden | 30 Tage |
| leere Suche | 15 Minuten | 24 Stunden |
| Produktdetails | 30 Tage | 180 Tage |

Der Service Worker cached App-Shell und Produktbilder. API-JSON wird bewusst vom Request Manager verwaltet, damit Fresh-/Stale-Zustand und Fehlerdiagnose eindeutig bleiben. Bereits gespeicherte Produkte und Berechnungen bleiben offline nutzbar; eine globale neue OFF-Suche benötigt weiterhin eine Netzwerkverbindung.

## Deterministische Mengenauflösung

- explizite Nutzer-Einheiten bleiben erhalten
- bewiesene Einzelgewichte stehen vor Portion und Packung
- Stückgewicht kann aus expliziter Stückzahl und Nettogewicht abgeleitet werden
- unbekannte zählbare Einheiten führen zur Kalibrierung statt zu einer Schätzung
- Einzel- und Gruppenwägung werden lokal produktbezogen gespeichert
- Kohlenhydrate werden stets aus aktuellem `carbohydratesPer100g` und gespeichertem Gewicht neu berechnet
- intern wird nicht vor dem Endergebnis gerundet

## Entwicklung

Voraussetzung: Node.js 22.12 oder neuer.

```bash
npm ci
npm run test:e2e:install
npm run check:all
```

Einzelne Prüfungen:

```bash
npm run typecheck
npm run lint
npm test
npm run check:server
npm run build
npm run check:pages
# nach npm run release:
npm run check:release
```

`npm run check:pages` verifiziert nach dem Build Pflichtdateien, relative Unterpfade, Manifest-Scope, Start-URL und App-Icons.

Für die lokale UI-Entwicklung:

```bash
npm run dev
```

Der Express-Server unter `server/index.mjs` ist nur noch ein optionaler Kompatibilitäts- und KI-Parser-Host. Er gehört nicht zum notwendigen GitHub-Pages-Laufzeitpfad.

## Qualität und nächste Ausbaustufe

Der Release-Gate umfasst TypeScript, Biome, Vitest, Server- und Script-Syntax, Playwright auf Chromium/WebKit, axe-core, npm audit, Vite/PWA-Build, Pages-Unterpfadprüfung, sichere ZIP-Extraktion, statische HTTP-Auslieferung und vollständige SHA-256-Abdeckung. Dependabot ist für npm und GitHub Actions vorkonfiguriert. Lighthouse CI und Sentry bleiben sinnvolle optionale Ergänzungen; Sentry sollte nur nach einer Datenschutzentscheidung aktiviert werden.

## Grenzen

Die App kann externe Dienste nicht verfügbar machen, wenn Open Food Facts oder das Netz des Geräts ausfallen. In diesem Fall liefert sie einen typisierten temporären Fehler oder vorhandene Reserve-Daten und erlaubt den sofortigen Retry. Eine vollständige weltweite Produktsuche kann nicht rein offline auf dem Gerät erfolgen, weil der globale OFF-Suchindex nicht Bestandteil der App ist.
