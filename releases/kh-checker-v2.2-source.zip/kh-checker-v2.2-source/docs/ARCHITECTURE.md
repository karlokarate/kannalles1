# KH Checker v2.2 – Architektur

## Leitprinzipien

1. Nährwerte und Berechnungen sind deterministisch.
2. Eine Nutzer-Einheit wird nie stillschweigend in eine andere Einheit umgedeutet.
3. Öffentliche API-Aufrufe werden durch Cache-first und Deduplizierung minimiert, nicht durch eine unbedienbare Oberfläche.
4. Der Originalfehler bleibt beobachtbar, auch wenn ein Fallback funktioniert.
5. OpenAI ist optional und darf ausschließlich Nutzersprache strukturieren.

## Suchpfad im statischen Browser-Build

1. Der lokale Parser extrahiert Produkt, Menge und Einheit.
2. Der Suchtext wird bereinigt, typografisch normalisiert und auf 120 Zeichen begrenzt.
3. Der backend-unabhängige Canonical Cache wird geprüft.
4. URL-Caches aus v2.1 können einmalig in den Canonical Cache migriert werden.
5. Die Browser-App fragt die OFF-Legacy-Suche ab.
6. Nur bei einem technischen Fehler folgt einmal Search-a-licious.
7. Eine gültige leere Antwort gilt als abgeschlossen und erzeugt keinen zweiten öffentlichen Request.
8. Treffer werden lokal nach Identität, Variante, Markt, Zustand und Datenqualität geordnet.

Search-a-licious bleibt der vorgesehene Volltextweg, wird aber bei direkter Browsernutzung wegen möglicher CORS-Ausfälle nicht als erster Endpunkt verwendet.

## Suchpfad mit Gateway

1. Der Browser ruft ausschließlich `/api/search` auf.
2. Der Gateway verwendet Search-a-licious als Primärweg.
3. Die Legacy-Suche folgt nur nach einem technischen Search-a-licious-Fehler.
4. Der Gateway liefert seine Upstream-Versuche als `gateway_attempts` zurück.
5. Der Browser führt bei eingebetteten Upstream-Fehlern nicht dieselben externen Anfragen noch einmal direkt aus.

## Request Manager

### In-Flight-Deduplizierung

Jede konkrete GET-URL besitzt höchstens einen laufenden Netzwerktask. Mehrere Aufrufer abonnieren denselben Task. Bricht eine UI-Ansicht ab, wird nur dieser Abonnent gelöst; der gemeinsame Request läuft bis Erfolg oder Timeout weiter und kann von einem sofortigen Retry übernommen werden. Nach jeder asynchronen Parser-, Cache-, Kalibrierungs- und Produktgrenze wird der UI-Abbruch erneut geprüft, damit ein alter Vorgang keinen Cache-Treffer oder Ergebniszustand mehr zurückschreibt.

### Keine lokale Sperre

`recordApiRequest` und `recordApiResponse` speichern ausschließlich Telemetrie. Auch oberhalb des Minutenrichtwerts oder bei `Retry-After` werfen diese Funktionen keinen Fehler und deaktivieren keinen Button.

### Fehlerdiagnose

Jeder Versuch erzeugt ein strukturiertes Diagnoseobjekt mit Backend, Label, URL, Startzeit, Dauer, Ergebnis, Status, Originalfehler, Antwortvorschau und optionalem Retry-After. Gateway-Upstream-Versuche werden mit dem Transportversuch zusammengeführt, aber nicht als Payload-Dublette gespeichert.

## Cache-Architektur

### Ebenen

1. begrenzter Memory-Cache für sofortige Zugriffe
2. kompakter `localStorage`-Spiegel nur für Canonical Search/Product Snapshots
3. IndexedDB für URL-Caches und langlebige Snapshots

`localStorage` wird vor IndexedDB gelesen, damit lokale Android-Viewer nicht bei jedem Treffer auf eine langsame oder blockierte Datenbanköffnung warten. IndexedDB wird über eine wiederverwendete Verbindung angesprochen. Nach einem Öffnungsfehler gilt ein kurzer Retry-Backoff.

API-Cache-Schreibvorgänge schreiben zuerst synchron in Memory und gegebenenfalls `localStorage`; die IndexedDB-Persistenz läuft anschließend im Hintergrund. Eine Cache-Generation wird nach dem potenziell langsamen Datenbank-Open direkt vor dem Write geprüft, sodass ein älterer Hintergrundvorgang einen geleerten Cache nicht wiederherstellt. Fachliche Daten wie Verlauf, Einstellungen und Kalibrierungen bleiben bestätigte IndexedDB-Transaktionen.

### Zeitstempel

Ein Canonical Snapshot übernimmt `api_meta.fetchedAt`. Stammen Daten aus einem stale URL-Cache, behalten sie deshalb das ursprüngliche Alter. Ein fehlgeschlagener Netzrefresh kann alte Daten nicht erneut für 24 beziehungsweise 30 Tage frisch machen.

### Gültigkeiten

- erfolgreiche Suche: 24 Stunden frisch, 30 Tage Reserve
- leere Suche: 15 Minuten frisch, 24 Stunden Reserve
- Produkt: 30 Tage frisch, 180 Tage Reserve
- Gateway-Suche: 10 Minuten Memory-Fresh, 24 Stunden Reserve
- Gateway-Produkt: 24 Stunden Memory-Fresh, 30 Tage Reserve
- Gateway-Produkt mit transient fehlgeschlagener v2-Anreicherung: 5 Minuten frisch, 24 Stunden Reserve

## Konkretes Produkt und Barcode

1. Nur der ausgewählte beziehungsweise eindeutig gewählte Treffer wird hydratisiert.
2. OFF API v3.6 ist primär.
3. Fehlende Nährwertfelder können im selben Produktvorgang einmalig über den kompakten v2-Endpunkt ergänzt und mit den v3.6-Mengenfeldern zusammengeführt werden.
4. Ein transienter v2-Fehler lässt nützliche v3.6-Teildaten sichtbar, löst im selben Vorgang aber keinen zweiten v2-Aufruf aus.
5. `quantity`, `product_quantity`, `serving_size` und `serving_quantity` erlauben die Rekonstruktion von Multipack-Einzelgewichten.
6. Erfolgreich erreichbare Antworten ohne Produkt werden als HTTP 404 klassifiziert, nicht als Netzwerkfehler.

## Manuelle Mengenauflösung

- Basis `100 g`: Gesamtgewicht kann direkt oder per Regler eingegeben werden.
- Basis `100 ml`: Gesamtvolumen wird in Millilitern eingegeben.
- Einzelwägung: direktes Gewicht einer Einheit.
- Gruppenwägung: `gemeinsames Gesamtgewicht / Anzahl`.
- Eine neue manuelle Messung ersetzt die vorherige manuelle Option derselben Einheit.
- Produktbezogene Kalibrierungen werden lokal gespeichert.

## Einheiten-Beweishierarchie

Ausreichend:

1. explizite Einzelangabe (`1 Riegel = 21,5 g`)
2. explizites Multipack-Einzelgewicht (`6 × 21,5 g`)
3. Stückzahl und Gesamtgewicht desselben Produkts (`30 Stück, 75 g`)
4. mindestens zwei kompatible explizite Produktbelege als generischer Konsens
5. persönliche, vom Nutzer gemessene Kalibrierung

Nicht ausreichend:

- allgemeine Herstellerportion ohne passende Einheit
- Gesamtpackungsgewicht als Ersatz für einen Riegel oder ein Stück
- Kategorie allein
- KI-Schätzung

## Server-Härtung

- feste OFF-Upstream-Hosts, GET-only und Zeitlimits
- `User-Agent` mit konfigurierbarer Kontaktadresse
- begrenzte Query-, Barcode- und JSON-Größen
- CORS-Allowlist über `CORS_ORIGINS`; ohne Konfiguration nur Loopback-Origin
- `X-Content-Type-Options`, `X-Frame-Options`, CSP ohne `unsafe-inline`, Referrer- und Permissions-Policy
- JSON-404 für unbekannte API-Routen
- kein Cache für HTML, Manifest und Service Worker; immutable Cache für gehashte Assets
- begrenzte Gateway- und KI-Rate-Limit-Maps
- wiederverwendeter OpenAI-Client, gecachter Prompt, 15-Sekunden-Timeout und maximal ein SDK-Retry

## PWA

Der Service Worker precacht die App-Shell. Produktbilder werden 30 Tage Cache-first gehalten und auf 80 Einträge begrenzt. API-JSON wird nicht vom Workbox-Runtime-Cache übernommen, sondern ausschließlich vom Request Manager verwaltet.
