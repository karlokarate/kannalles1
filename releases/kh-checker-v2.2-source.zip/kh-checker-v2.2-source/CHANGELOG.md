# Changelog

## 2.2.0

### Fehlerdiagnose und Bedienung

- tatsächlicher Netzwerk-, CORS-, Timeout-, JSON- oder HTTP-Fehler direkt im UI
- vollständige Endpunkte, Status, Startzeit, Dauer, Antwortvorschau, Retry-After und Cache-Alter pro Versuch
- kopierbare JSON-Diagnose
- erfolgreiche Fallbacks verschweigen den ursprünglichen Fehler nicht mehr
- Suchbutton bleibt während einer Anfrage bedienbar und startet sofort neu
- lokaler Countdown, Request-Lock und persistente Cooldowns vollständig entfernt
- ungültige beziehungsweise gemischte HTTP/HTTPS-Gateway-URLs werden sichtbar validiert und nicht verwendet
- Cache-Größe und verständliche Backend-Bezeichnungen in der Oberfläche

### API- und Cache-Logik

- backend-unabhängiger kanonischer Suchcache für Schreibvarianten wie `Kinder Bueno` und `Kinderbueno`
- Canonical Cache wird vor jeder neuen API-Anfrage geprüft
- identische parallele GET-Anfragen werden zusammengeführt
- ein abgebrochener UI-Abonnent beendet den Shared Request nicht mehr
- sofortiger Retry kann deshalb denselben laufenden Request übernehmen
- gültige leere Suchantwort löst keine zweite öffentliche Suche aus
- Gateway-Upstream-Diagnosen verhindern doppelte Browser-Fallbacks
- Suchtexte werden auf 120 Zeichen begrenzt
- veraltete URL-Cache-Daten behalten beim Canonical-Snapshot ihr ursprüngliches Abrufdatum
- stale Daten werden nach einem fehlgeschlagenen Refresh nicht wieder als frisch markiert
- Gateway-Transportfelder werden vor dem Speichern entfernt
- Product-not-found wird zuverlässig als HTTP 404 klassifiziert
- Produkt-404 vom Gateway wird als autoritativ behandelt
- bereits abgebrochene UI-Operationen werden an allen asynchronen Cache-, Parser- und Produktgrenzen verworfen
- fehlende v3.6-Nährwerte werden innerhalb desselben Produktvorgangs genau einmal über v2 ergänzt
- nützliche v3.6-Teildaten bleiben bei einem transienten v2-Ausfall nutzbar, ohne einen doppelten Fallback im selben Vorgang

### Persistenz und Performance

- begrenzter Memory-Cache
- kanonischer `localStorage`-Fallback für Such- und Produkt-Snapshots
- wiederverwendete IndexedDB-Verbindung statt Öffnen und Schließen pro Transaktion
- IndexedDB-Transaktionen gelten erst nach `transaction.complete` als gespeichert
- Retry-Backoff nach blockierter oder fehlgeschlagener IndexedDB-Öffnung
- IndexedDB-API-Cache-Schreibvorgänge blockieren die Ergebnisanzeige nicht mehr
- API-Cache-Bereinigung und zusammengeführte Statistik über alle Speicherschichten
- Generationsschutz gegen verspätete IndexedDB-Hintergrundwrites nach bewusstem Cache-Leeren
- PWA-Bildcache auf v2.2 aktualisiert und bei Speicherknappheit bereinigbar

### Server-Gateway

- Search-a-licious serverseitig primär, Legacy-Suche nur nach technischem Fehler
- OFF API v3.6 primär und v2 als kompakter Produktfallback
- kanonische Keys auch für Suchbegriffe ohne ASCII-Zeichen
- begrenzter Fresh-/Stale-Cache und In-Flight-Deduplizierung
- tote `/api/document`-Route entfernt
- unbekannte `/api`-Routen liefern JSON 404 statt SPA-HTML
- sicherere CORS-Allowlist, Sicherheitsheader und Host-/Port-Validierung
- abgestufte statische Cache-Header für HTML, Service Worker und gehashte Assets
- CSP ohne `unsafe-inline` sowie getrennte Worker- und Manifest-Regeln
- transiente v2-Produktfallback-Fehler frieren Teildaten nur kurz statt für den normalen 24-Stunden-Zeitraum ein
- interne 500-Details werden im Produktionsmodus nicht offengelegt
- wiederverwendeter OpenAI-Client und Prompt, feste Zeitlimits und begrenzte Retry-Anzahl
- begrenzte und bereinigte KI-Rate-Limit-Buckets

### Stabilität und Qualität

- Race beim initialen Laden und Speichern der Einstellungen behoben
- Race zwischen älteren und neueren Produktladevorgängen behoben
- Cleanup laufender UI-Abonnenten beim Unmount
- 52 automatisierte Tests
- zusätzliche Tests für Shared-Request-Retry, Abort-vor-Cache-Rückgabe, Empty-Result-Sicherheit, Stale-Promotion, Gateway-Deduplizierung, Query-Limit, v3/v2-Produkt-Merge und Produkt-404
- Biome 2.5.3 als reproduzierbarer Lint-Schritt in `npm run check`
- `dotenv` auf 17.4.2 und React-Typdefinitionen auf 19.2.17 aktualisiert
- Node-Typdefinitionen bewusst auf der Node-22-Linie 22.20.1 ausgerichtet und Runtime-Mindestversion auf 22.12 passend zu Vite 8 präzisiert

## 2.1.0

- statischer Browser-Build verwendet zuerst den browserkompatiblen Open-Food-Facts-Suchweg
- Search-a-licious bleibt serverseitiger beziehungsweise einmaliger Erreichbarkeits-Fallback
- ausgewählte Produkte werden einmal per OFF API v3.6 hydratisiert, damit ausgelassene Mengen- und Portionsfelder wieder verfügbar sind
- Kinder-Bueno- und vergleichbare Multipack-Einzelportionen werden aus Angaben wie `2 × 21,5 g` abgeleitet
- universeller manueller Gesamtgewichts- beziehungsweise Gesamtmengen-Editor
- direkte Zahleneingabe und Schieberegler
- Einzelwägung und Gruppenwägung für zählbare Produkte
- aus einem gemessenen Gesamtgewicht wird automatisch ein lokales Einheitengewicht gespeichert
- manuelle Portionsoptionen werden bei erneuter Bearbeitung ersetzt statt dupliziert

## 2.0.0

- deterministische Einheiten-Beweishierarchie
- Gruppenwägung für fehlende Stückgewichte
- persönliche Stückgewichts-Kalibrierungen
- In-Flight-Request-Deduplizierung
- IndexedDB Fresh-/Stale-Cache
- lokale Budgets und blockierende Cooldowns nach Retry-After
- generische Standardpfade ohne Produktdetail-Fan-out
- optionaler OpenAI-Structured-Output-Parser
