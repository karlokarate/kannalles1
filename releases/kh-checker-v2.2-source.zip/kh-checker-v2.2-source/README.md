# KH Checker v2.2

Installierbare Web-App für Android, iOS und Desktop. KH Checker sucht reale Markenprodukte und generische Lebensmittel, löst Portionen deterministisch auf und berechnet Kohlenhydrate lokal. Für die normale statische Nutzung sind weder npm noch ein eigener Server oder OpenAI erforderlich.

## Was v2.2 behebt

### Sichtbarer Originalfehler statt Sammelmeldung

Netzwerk-, CORS-, Timeout-, JSON-, HTTP- und Rate-Limit-Fehler werden direkt in der Oberfläche angezeigt. Die Diagnose enthält pro Versuch:

- Datenquelle und vollständigen Endpunkt
- HTTP-Status, Fehlername und Originalmeldung
- Startzeit und Dauer
- Anfang einer fehlerhaften Serverantwort
- `Retry-After` als reinen Hinweis
- Cache-Alter und verwendete Cache-Quelle
- Online-Status und App-Version

Die Diagnose kann als JSON kopiert werden. Hat ein Fallback funktioniert, bleibt der Fehler des ersten API-Wegs trotzdem sichtbar.

### Keine künstliche Suchsperre

Der Suchbutton wird nur bei leerem Suchfeld deaktiviert. Während einer laufenden Suche bleibt er bedienbar und trägt die Beschriftung **„Suche neu starten“**. Ein erneuter Klick beendet nur den bisherigen UI-Abonnenten und hängt die neue Suche an eine bereits laufende identische GET-Anfrage an. Es gibt keinen lokalen Countdown, keinen gespeicherten Cooldown und keine blockierende Wartezeit.

`Retry-After` sowie die öffentlichen Minutenrichtwerte werden ausschließlich als Telemetrie angezeigt. Die tatsächliche Last wird durch Cache-first, Request-Deduplizierung und sparsame Fallbacks reduziert.

### Kinder-Bueno- und Suchcache-Fix

Suchergebnisse werden zusätzlich zur konkreten URL unter einem backend-unabhängigen kanonischen Suchschlüssel gespeichert. Dadurch verwenden beispielsweise diese Eingaben denselben Eintrag:

- `Kinder Bueno`
- `Kinderbueno`
- abweichende Groß-/Kleinschreibung
- zusätzliche Leer- oder Trennzeichen

Ein erfolgreicher Treffer über einen Fallback wird deshalb bei der nächsten gleichwertigen Suche vor jeder API-Anfrage gefunden. Veraltete Reserve-Daten behalten ihr ursprüngliches Abrufdatum und werden nach einem fehlgeschlagenen Refresh nicht versehentlich wieder als frisch markiert. Bereits abgebrochene UI-Vorgänge dürfen auch aus einem schnellen Cache-Treffer keinen älteren Bildschirmzustand mehr zurückschreiben.

### Optimierte öffentliche API-Abfragen

Ohne eigenen Gateway gilt im Browser:

1. kanonischer Suchcache
2. vorhandener URL-Cache aus älteren Versionen
3. Open-Food-Facts-Legacy-Suche als browserkompatibler Primärweg
4. Search-a-licious nur, wenn der Primärweg technisch fehlgeschlagen ist

Eine gültige leere Antwort löst keine zweite öffentliche Suche aus. Bei einem konfigurierten Gateway übernimmt dieser Search-a-licious serverseitig und nutzt den Legacy-Weg nur bei einem technischen Fehler. Liefert der Gateway bereits Upstream-Diagnosen, wiederholt der Browser dieselben externen Aufrufe nicht erneut.

Suchtexte werden auf 120 Zeichen begrenzt. Gleiche parallele Requests werden zusammengeführt. Ein ausgewähltes Produkt wird gezielt über seinen Barcode hydratisiert; es gibt keinen Produktdetail-Fan-out über alle Treffer. Fehlen in der v3.6-Antwort Kohlenhydrate, wird der kompakte v2-Kompatibilitätsabruf innerhalb desselben Produktvorgangs höchstens einmal ausgeführt und mit Mengen- sowie Portionsfeldern zusammengeführt.

### Robuster Mehrschicht-Cache

- Arbeitsspeicher für den schnellsten Zugriff
- kompakter `localStorage`-Spiegel für kanonische Such- und Produktdaten
- IndexedDB als größerer Langzeitspeicher
- asynchrone IndexedDB-Schreibvorgänge, damit ein langsamer Android-WebView die Ergebnisanzeige nicht verzögert
- begrenzte Anzahl von Speicher- und Fallback-Einträgen
- temporärer IndexedDB-Retry-Backoff nach blockierten oder fehlgeschlagenen Öffnungen
- Generationsschutz, damit ein älterer Hintergrund-Write einen bewusst geleerten Cache nicht nachträglich wiederherstellt
- Bereinigung abgelaufener Einträge

Fresh-/Reserve-Zeiten:

| Daten | Frisch | Ausfallreserve |
|---|---:|---:|
| erfolgreiche Suche | 24 Stunden | 30 Tage |
| leere Suche | 15 Minuten | 24 Stunden |
| Produktdetails | 30 Tage | 180 Tage |

Der Service Worker verwaltet nur App-Shell und Produktbilder. API-JSON bleibt unter Kontrolle des Request-Managers.

## Search-a-licious im Versionsvergleich

Die alte v1.4 verwendete Search-a-licious direkt als primäre Browsersuche und die Legacy-Suche als Fallback. Search-a-licious ist fachlich weiterhin der vorgesehene Volltextsuchweg, kann bei direkten Browseraufrufen jedoch an CORS scheitern. Deshalb nutzt die statische v2.2-App zuerst den im Browser praktisch zuverlässigeren OFF-Legacy-Endpunkt. Mit dem mitgelieferten Server-Gateway ist Search-a-licious wieder primär, da die Browser-CORS-Schranke dort nicht greift.

Search-a-licious wurde also nicht entfernt, sondern abhängig von der Laufzeit an die sichere Stelle verschoben.

## Portionen und manuelle Mengen

Nach der Auswahl eines konkreten Produkts lädt die App genau diesen Barcode nach. Dadurch werden Felder wie `quantity`, `product_quantity`, `serving_size` und `serving_quantity` ergänzt, wenn sie im kompakten Suchtreffer fehlen.

Beispiele:

- Kinder Bueno `2 × 21,5 g` → 21,5 g pro Riegel
- Nutella `15 g` Herstellerportion → editierbare Portion
- Bifi `20 g` Einzelpackung → editierbares Stück

Sobald ein Nährwert pro 100 g oder 100 ml vorhanden ist, kann die Menge bei jedem Produkt manuell geändert werden:

- direkte Zahleneingabe
- Schieberegler
- Gesamtgewicht beziehungsweise Gesamtvolumen
- Gewicht einer Einheit
- Gruppenwägung, zum Beispiel 10 Salzstangen gemeinsam wiegen

Bei einer Gruppenwägung wird `Gesamtgewicht / Anzahl` als Einheitengewicht berechnet und produktbezogen lokal gespeichert. Eine neue manuelle Messung ersetzt die vorherige manuelle Option statt weitere Dubletten zu erzeugen.

Bei einer Nährwertbasis pro 100 ml arbeitet der Editor in Millilitern. Ohne bekannte Dichte wird keine Umrechnung zwischen Gramm und Millilitern erfunden.

## Vorgebaute App

Im Komplett-ZIP liegen die direkt nutzbaren Dateien auf oberster Ebene:

```text
index.html
assets/
icons/
manifest.webmanifest
sw.js
workbox-*.js
API-DIAGNOSE.html
README-ERST-LESEN.html
RELEASE-NOTES-v2.2.txt
ENTWICKLER-QUELLCODE-v2.2.zip
VERSION.txt
SHA256SUMS.txt
```

### Android

1. Einen bisherigen KH-Checker-Ordner vollständig entfernen.
2. v2.2 in einen neuen, leeren Ordner entpacken.
3. `index.html` über den lokalen Viewer öffnen.
4. Erscheint noch eine alte Oberfläche, Website-Daten beziehungsweise Service-Worker-Cache des lokalen `127.0.0.1`-Hosts löschen.

Eine URL wie `http://127.0.0.1:18121/...` gehört zum lokalen Android-Dateibetrachter. Die Produktdaten werden weiterhin von öffentlichen HTTPS-Endpunkten geladen.

### iPhone und iPad

Für eine PWA-Installation müssen die fertigen statischen Dateien über HTTPS bereitgestellt werden. Danach in Safari **Teilen → Zum Home-Bildschirm** wählen.

## Optionaler Daten-Gateway

Der mitgelieferte Express-Server bietet:

- Search-a-licious als serverseitige Primärsuche
- Legacy-Suchfallback nur bei technischem Fehler
- OFF API v3.6 als primären Produktabruf und v2 als kompakten Kompatibilitätsfallback
- In-Flight-Deduplizierung und begrenzten Fresh-/Stale-Memory-Cache
- kurze Wiederholungsfrist für nur teilweise verfügbare Produkte nach einem transienten v2-Fehler statt 24 Stunden eingefrorener Teildaten
- vollständige Upstream-Diagnosen
- Zeitlimits, Sicherheitsheader, API-404-Antworten und statische Cache-Header
- optionalen OpenAI-Parser ohne Schlüssel im Frontend

Konfiguration:

```bash
cp .env.example .env
npm ci
npm run build
npm start
```

Für einen produktiven Cross-Origin-Betrieb muss `CORS_ORIGINS` als explizite Allowlist gesetzt werden. `OFF_USER_AGENT` sollte eine erreichbare Kontaktadresse enthalten.

## Entwicklung und Qualitätsprüfung

Voraussetzung: Node.js 22.12 oder neuer.

```bash
npm ci
npm run typecheck
npm run lint
npm test
npm run check:server
npm run build
# oder alles:
npm run check
```

Die v2.2-Tests decken unter anderem ab:

- Kinder-Bueno-Schreibvarianten verwenden denselben Cache
- ein sofortiger Retry hängt sich an den bestehenden Shared Request
- ein bereits abgebrochener Vorgang kann keinen Cache-Treffer mehr in die alte UI zurückschreiben
- gültige leere Suchen erzeugen keinen zweiten öffentlichen Request
- Reserve-Daten werden nicht als frisch hochgestuft
- Gateway-Upstream-Fehler werden nicht im Browser doppelt abgefragt
- Produkt-Not-Found wird als HTTP 404 statt Netzwerkfehler gemeldet
- v3.6-Teildaten werden einmalig mit dem kompakten v2-Nährwertfallback zusammengeführt
- bei einem transienten v2-Ausfall bleiben nützliche v3-Teildaten verwendbar, ohne denselben Fallback im Vorgang doppelt zu senden
- `Retry-After` erzeugt keinen lokalen Lock
- Salzstangen-Gruppenwägung und wiederverwendbares Stückgewicht
- Kinder Bueno 21,5 g statt 43 g pro Riegel
- direkte Gramm- und Milliliterkorrektur
- strikte Einheiten- und Produktidentitätslogik

Die Quellcodeprüfung nutzt zusätzlich Biome 2.5.3. Für die nächste Ausbaustufe sind dauerhaft automatisierte Playwright-Gerätetests, Lighthouse CI, axe-core, Sentry sowie Renovate oder Dependabot sinnvoll.
