export type FoodUnit =
  | 'g'
  | 'kg'
  | 'ml'
  | 'piece'
  | 'bar'
  | 'slice'
  | 'portion'
  | 'package';

export type ParseStatus = 'parsed' | 'needs_clarification' | 'unsupported';
export type ResolutionMode = 'generic_category' | 'exact_product' | 'barcode';
export type Confidence = 'high' | 'medium' | 'low' | 'missing';

export type ApiBackend =
  | 'gateway'
  | 'search-a-licious'
  | 'open-food-facts-legacy'
  | 'open-food-facts-v3'
  | 'open-food-facts-v2'
  | 'query-cache'
  | 'product-cache';

export type ApiAttemptOutcome =
  | 'cache-hit'
  | 'success'
  | 'http-error'
  | 'rate-limit'
  | 'network-error'
  | 'timeout'
  | 'parse-error'
  | 'aborted';

export interface ApiAttemptDiagnostic {
  backend: ApiBackend;
  label: string;
  url: string;
  startedAt: string;
  durationMs: number;
  outcome: ApiAttemptOutcome;
  status?: number;
  errorName?: string;
  errorMessage?: string;
  responsePreview?: string;
  retryAfterMs?: number;
  cacheAgeMs?: number;
}

export interface ApiResponseMeta {
  cacheStatus: 'network' | 'fresh-cache' | 'stale-cache';
  fetchedAt: string;
  sourceUrl: string;
  backend?: ApiBackend;
  originBackend?: ApiBackend;
  networkAttempted?: boolean;
  durationMs?: number;
  cacheAgeMs?: number;
  cacheKey?: string;
  attempts?: ApiAttemptDiagnostic[];
  /** Why cached data or a secondary backend was used. */
  fallbackReason?: 'offline' | 'rate-limit' | 'network' | 'timeout' | 'http' | 'parse';
  fallbackStatus?: number;
  /** `local-budget` is retained only for metadata written by releases before 2.2. */
  fallbackOrigin?: 'local-budget' | 'remote-limit' | 'remote-overload';
  retryAt?: string;
}

export interface ParsedFoodRequest {
  status: ParseStatus;
  rawInput: string;
  product: {
    name: string;
    brand: string | null;
    variant: string | null;
  };
  amount: {
    value: number;
    unit: FoodUnit;
    /** True only when the user explicitly supplied a number. */
    valueExplicit?: boolean;
    /** True only when the user explicitly supplied the unit word. */
    unitExplicit?: boolean;
  };
  resolutionMode: ResolutionMode;
  barcode: string | null;
  clarificationQuestion: string | null;
  parser: 'local' | 'openai';
}

export interface SearchNutriments {
  carbohydrates_100g?: number;
  carbohydrates_100ml?: number;
  carbohydrates_serving?: number;
  carbohydrates_prepared_100g?: number;
  carbohydrates_prepared_100ml?: number;
  carbohydrates_prepared_serving?: number;
  [key: string]: number | string | undefined;
}

export interface SearchHit {
  code?: string;
  product_name?: string;
  product_name_de?: string;
  generic_name?: string;
  generic_name_de?: string;
  brands?: string | string[];
  quantity?: string;
  countries_tags?: string[];
  categories_tags?: string[];
  nutriments?: SearchNutriments;
  image_front_url?: string;
  serving_size?: string;
  serving_quantity?: number | string;
  product_quantity?: number | string;
  product_quantity_unit?: string;
  nutrition_data_per?: string;
  nutrition_data_prepared_per?: string;
  data_quality_errors_tags?: string[];
  unique_scans_n?: number;
  completeness?: number;
  _score?: number;
  api_meta?: ApiResponseMeta;
}

export interface SearchResponse {
  hits: SearchHit[];
  count?: number;
  page?: number;
  page_size?: number;
  page_count?: number;
  took?: number;
  timed_out?: boolean;
  warnings?: unknown[] | null;
  errors?: unknown[];
  api_meta?: ApiResponseMeta;
  source?: 'gateway' | 'search-a-licious' | 'open-food-facts-legacy' | 'none';
  gateway_attempts?: ApiAttemptDiagnostic[];
  query_used?: string;
}

export interface OffProduct {
  code?: string;
  product_name?: string;
  product_name_de?: string;
  generic_name?: string;
  generic_name_de?: string;
  brands?: string;
  quantity?: string;
  product_quantity?: number | string;
  product_quantity_unit?: string;
  serving_size?: string;
  serving_quantity?: number | string;
  image_front_url?: string;
  categories_tags?: string[];
  countries_tags?: string[];
  data_quality_errors_tags?: string[];
  nutrition_data_per?: string;
  nutrition_data_prepared_per?: string;
  nutriments?: SearchNutriments;
}

export interface OffProductResponse {
  status?: string;
  code?: string;
  product?: OffProduct;
  errors?: unknown[];
  warnings?: unknown[];
  api_meta?: ApiResponseMeta;
  gateway_attempts?: ApiAttemptDiagnostic[];
}

export interface ProductSummary {
  barcode: string | null;
  name: string;
  brand: string | null;
  imageUrl: string | null;
  packageDescription: string | null;
  packageWeightG: number | null;
  servingDescription: string | null;
  servingWeightG: number | null;
  categories: string[];
}

export type PortionSource =
  | 'explicit-unit'
  | 'manufacturer-serving'
  | 'single-package'
  | 'package'
  | 'mass'
  | 'volume'
  | 'manual'
  | 'generic-consensus';

/**
 * A safe, user-selectable calculation basis. `weightG` is always the weight
 * of exactly one selected unit, never the total requested amount.
 */
export interface PortionOption {
  id: string;
  unit: FoodUnit;
  label: string;
  weightG: number | null;
  volumeMl: number | null;
  source: PortionSource;
  confidence: Confidence;
  note: string;
  recommended: boolean;
}

export interface CalculationResult {
  id: string;
  createdAt: string;
  request: ParsedFoodRequest;
  product: ProductSummary;
  mode: 'exact' | 'generic' | 'manual';
  status: 'calculated' | 'needs_weight' | 'not_found' | 'error';
  carbohydratesG: number | null;
  carbohydratesPer100: number | null;
  basis: '100g' | '100ml';
  totalMassG: number | null;
  totalVolumeMl: number | null;
  unitWeightG: number | null;
  amount: number;
  unit: FoodUnit;
  confidence: Confidence;
  sourceLabel: string;
  methodLabel: string;
  sampleSize: number | null;
  middleRange: { from: number; to: number } | null;
  candidates: SearchHit[];
  notes: string[];
  favorite: boolean;
  portionOptions: PortionOption[];
  selectedPortionId: string | null;
}

export interface ManualFormValues {
  productName: string;
  brand: string;
  amount: number;
  unit: FoodUnit;
  barcode: string;
  unitWeightG: number | null;
  carbsPer100g: number | null;
}

export interface AppSettings {
  aiEnabled: boolean;
  aiParseUrl: string;
  decimalPlaces: 0 | 1 | 2;
  searchPageSize: 10 | 15 | 20;
  preferGermanMarket: boolean;
  saveHistory: boolean;
  /** Optional same-origin or HTTPS gateway base URL for server-side OFF requests. */
  dataGatewayUrl: string;
}

export interface WeightMeasurement {
  unitWeightG: number;
  measuredPieces: number | null;
  measuredTotalWeightG: number | null;
}

export interface PieceCalibration {
  key: string;
  productName: string;
  barcode: string | null;
  unit: FoodUnit;
  weightG: number;
  measuredPieces: number | null;
  measuredTotalWeightG: number | null;
  updatedAt: string;
}
