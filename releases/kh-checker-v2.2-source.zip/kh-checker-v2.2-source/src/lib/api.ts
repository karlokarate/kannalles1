import type {
  ApiAttemptDiagnostic,
  ApiBackend,
  ApiResponseMeta,
  OffProduct,
  OffProductResponse,
  SearchHit,
  SearchResponse
} from '../types';
import { normalizeText } from './format';
import { correctCommonFoodTypos } from './query';
import { getApiCache, putApiCache } from './storage';
import {
  clearApiGovernor,
  getApiUsageSnapshot,
  parseRetryAfter,
  recordApiRequest,
  recordApiResponse
} from './apiGovernor';
import type { ApiBucket } from './apiGovernor';

const SEARCH_A_LICIOUS_URL = 'https://search.openfoodfacts.org/search';
const OFF_LEGACY_SEARCH_URL = 'https://world.openfoodfacts.org/cgi/search.pl';
const OFF_V3_PRODUCT_URL = 'https://world.openfoodfacts.org/api/v3.6/product';
const OFF_V2_PRODUCT_URL = 'https://world.openfoodfacts.org/api/v2/product';

const CACHE_NAMESPACE = 'kh-v2.2';
const LEGACY_CACHE_NAMESPACE = 'kh-v2';
const NETWORK_SEARCH_PAGE_SIZE = 20;
const MAX_SEARCH_QUERY_LENGTH = 120;
const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;

const SEARCH_FRESH_MS = 24 * HOUR;
const SEARCH_STALE_MS = 30 * DAY;
const EMPTY_SEARCH_FRESH_MS = 15 * 60 * 1000;
const EMPTY_SEARCH_STALE_MS = 24 * HOUR;
const PRODUCT_FRESH_MS = 30 * DAY;
const PRODUCT_STALE_MS = 180 * DAY;

export const SEARCH_FIELDS = [
  'code',
  'product_name',
  'product_name_de',
  'generic_name',
  'generic_name_de',
  'brands',
  'quantity',
  'product_quantity',
  'product_quantity_unit',
  'serving_size',
  'serving_quantity',
  'nutrition_data_per',
  'nutrition_data_prepared_per',
  'countries_tags',
  'categories_tags',
  'nutriments',
  'image_front_url',
  'data_quality_errors_tags',
  'unique_scans_n',
  'completeness'
];

const PRODUCT_FIELDS = [...SEARCH_FIELDS];

export interface SearchFoodOptions {
  /** Kept for API compatibility. v2.2 fetches up to 20 variants in one request. */
  preserveVariants?: boolean;
  /** Optional server base URL. The bundled server performs Search-a-licious calls server-side. */
  gatewayUrl?: string;
}

export interface ProductRequestOptions {
  gatewayUrl?: string;
}

interface LegacySearchResponse {
  products?: SearchHit[];
  count?: number;
  page?: number;
  page_size?: number;
  page_count?: number;
  api_meta?: ApiResponseMeta;
}

interface FetchPolicy {
  bucket: ApiBucket;
  backend: ApiBackend;
  label: string;
  freshMs: number;
  staleMs: number;
  timeoutMs?: number;
}

interface NetworkResult<T> {
  data: T;
  fetchedAt: number;
  attempt: ApiAttemptDiagnostic;
}

interface InFlightTask<T> {
  controller: AbortController;
  promise: Promise<NetworkResult<T>>;
  subscribers: number;
  settled: boolean;
}

interface CachedSearchValue {
  response: SearchResponse;
  sourceUrl: string;
  originBackend: ApiBackend;
}

interface CachedProductValue {
  response: OffProductResponse;
  sourceUrl: string;
  originBackend: ApiBackend;
}

type SearchBackend = 'gateway' | 'search-a-licious' | 'open-food-facts-legacy';
type DataSourceErrorKind = 'http' | 'rate-limit' | 'network' | 'timeout' | 'parse' | 'aborted';

const inFlight = new Map<string, InFlightTask<unknown>>();

export { clearApiGovernor, getApiUsageSnapshot };

export function cancelPendingApiRequests(): void {
  for (const task of inFlight.values()) {
    task.controller.abort(new DOMException('API-Cache wurde geleert.', 'AbortError'));
  }
  inFlight.clear();
}

export class DataSourceError extends Error {
  readonly status?: number;
  readonly attempts: ApiAttemptDiagnostic[];
  readonly retryAt?: number;

  constructor(
    message: string,
    readonly kind: DataSourceErrorKind,
    options: {
      status?: number;
      attempts?: ApiAttemptDiagnostic[];
      retryAt?: number;
      cause?: unknown;
    } = {}
  ) {
    super(message, options.cause !== undefined ? { cause: options.cause } : undefined);
    this.name = 'DataSourceError';
    this.status = options.status;
    this.attempts = options.attempts ?? [];
    this.retryAt = options.retryAt;
  }
}

function isOffline(): boolean {
  try {
    return typeof navigator !== 'undefined' && navigator.onLine === false;
  } catch {
    return false;
  }
}

function throwIfAborted(signal?: AbortSignal): void {
  if (!signal?.aborted) return;
  throw new DataSourceError('Anfrage abgebrochen', 'aborted', {
    cause: signal.reason
  });
}

function errorName(error: unknown): string {
  if (error instanceof Error) return error.name || 'Error';
  return typeof error;
}

function errorMessage(error: unknown): string {
  if (error instanceof Error) return error.message || String(error);
  return String(error);
}

function cleanPreview(value: string): string {
  return value.replace(/\s+/g, ' ').trim().slice(0, 360);
}

function embeddedGatewayAttempts(value: string): ApiAttemptDiagnostic[] {
  try {
    const parsed = JSON.parse(value) as { attempts?: unknown };
    if (!Array.isArray(parsed.attempts)) return [];
    return parsed.attempts.filter((candidate): candidate is ApiAttemptDiagnostic => {
      const attempt = candidate as Partial<ApiAttemptDiagnostic>;
      return typeof attempt.backend === 'string'
        && typeof attempt.label === 'string'
        && typeof attempt.url === 'string'
        && typeof attempt.startedAt === 'string'
        && typeof attempt.durationMs === 'number'
        && typeof attempt.outcome === 'string';
    });
  } catch {
    return [];
  }
}

function meta(
  cacheStatus: ApiResponseMeta['cacheStatus'],
  storedAt: number,
  sourceUrl: string,
  options: Partial<Omit<ApiResponseMeta, 'cacheStatus' | 'fetchedAt' | 'sourceUrl'>> = {}
): ApiResponseMeta {
  return {
    cacheStatus,
    fetchedAt: new Date(storedAt).toISOString(),
    sourceUrl,
    ...options
  };
}

function attachMeta<T>(value: T, responseMeta: ApiResponseMeta): T {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return { ...(value as Record<string, unknown>), api_meta: responseMeta } as T;
  }
  return value;
}

function stripMeta<T extends object>(value: T): T {
  const {
    api_meta: _ignoredMeta,
    gateway_attempts: _ignoredGatewayAttempts,
    ...rest
  } = value as T & { api_meta?: ApiResponseMeta; gateway_attempts?: ApiAttemptDiagnostic[] };
  return rest as T;
}

function cacheTimestampFromMeta(responseMeta: ApiResponseMeta | undefined, now = Date.now()): number {
  if (!responseMeta?.fetchedAt) return now;
  const parsed = Date.parse(responseMeta.fetchedAt);
  if (!Number.isFinite(parsed) || parsed <= 0) return now;
  // Never let an upstream clock extend a local cache into the future. Keeping
  // the original timestamp also prevents stale URL-cache data from being
  // promoted to a fresh canonical entry after a failed network refresh.
  return Math.min(now, parsed);
}

function httpCacheKey(url: string): string {
  return `${CACHE_NAMESPACE}:http:${url}`;
}

function legacyHttpCacheKey(url: string): string {
  return `${LEGACY_CACHE_NAMESPACE}:${url}`;
}

function searchQueryCacheKey(query: string): string {
  const compact = normalizeText(query).replace(/[^a-z0-9]+/g, '');
  return `${CACHE_NAMESPACE}:search-query:v1:${compact || encodeURIComponent(query.toLocaleLowerCase('de-DE'))}`;
}

function productSnapshotCacheKey(code: string): string {
  return `${CACHE_NAMESPACE}:product:${code}`;
}

async function readBestCache<T>(
  keys: string[],
  policy: Pick<FetchPolicy, 'freshMs' | 'staleMs'>,
  now = Date.now()
): Promise<{ entry: { key: string; value: T; storedAt: number; expiresAt: number; staleUntil: number }; fresh: boolean } | null> {
  const entries = (await Promise.all(keys.map(async (key) => ({ key, entry: await getApiCache<T>(key) }))))
    .filter((item): item is { key: string; entry: NonNullable<Awaited<ReturnType<typeof getApiCache<T>>>> } => Boolean(item.entry))
    .sort((a, b) => b.entry.storedAt - a.entry.storedAt);
  const selected = entries[0];
  if (!selected) return null;

  // Apply the current policy to old v2.1 cache entries as well. This upgrades
  // useful existing data instead of forcing a new request solely because an
  // older release used a shorter expiry window.
  const effectiveExpiresAt = Math.max(selected.entry.expiresAt, selected.entry.storedAt + policy.freshMs);
  const effectiveStaleUntil = Math.max(selected.entry.staleUntil, selected.entry.storedAt + policy.staleMs);
  if (effectiveStaleUntil <= now) return null;

  return {
    entry: {
      ...selected.entry,
      key: selected.key,
      expiresAt: effectiveExpiresAt,
      staleUntil: effectiveStaleUntil
    },
    fresh: effectiveExpiresAt > now
  };
}

function cacheHitAttempt(
  backend: ApiBackend,
  label: string,
  url: string,
  storedAt: number,
  now = Date.now()
): ApiAttemptDiagnostic {
  return {
    backend,
    label,
    url,
    startedAt: new Date(now).toISOString(),
    durationMs: 0,
    outcome: 'cache-hit',
    cacheAgeMs: Math.max(0, now - storedAt)
  };
}

function fallbackReason(error: DataSourceError): ApiResponseMeta['fallbackReason'] {
  if (error.kind === 'rate-limit') return 'rate-limit';
  if (error.kind === 'network') return 'network';
  if (error.kind === 'timeout') return 'timeout';
  if (error.kind === 'parse') return 'parse';
  if (error.kind === 'http') return 'http';
  return 'network';
}

async function networkJson<T>(
  url: string,
  policy: FetchPolicy,
  controller: AbortController
): Promise<NetworkResult<T>> {
  const startedAt = Date.now();
  const startedIso = new Date(startedAt).toISOString();
  const timeoutMs = policy.timeoutMs ?? 10_000;
  let timedOut = false;
  let timeout = 0;

  recordApiRequest(policy.bucket, startedAt);
  timeout = globalThis.setTimeout(() => {
    timedOut = true;
    controller.abort(new DOMException('Timeout', 'TimeoutError'));
  }, timeoutMs) as unknown as number;

  try {
    const response = await fetch(url, {
      method: 'GET',
      mode: 'cors',
      credentials: 'omit',
      cache: 'no-store',
      referrerPolicy: 'no-referrer',
      signal: controller.signal
    });
    const responseText = await response.text();
    const durationMs = Date.now() - startedAt;
    const retryAfterMs = parseRetryAfter(response.headers.get('Retry-After'));
    recordApiResponse(policy.bucket, response.status, retryAfterMs, Date.now());

    if (response.status === 429 || response.status === 503) {
      const upstreamAttempts = embeddedGatewayAttempts(responseText);
      const attempt: ApiAttemptDiagnostic = {
        backend: policy.backend,
        label: policy.label,
        url,
        startedAt: startedIso,
        durationMs,
        outcome: 'rate-limit',
        status: response.status,
        errorName: 'HTTPError',
        errorMessage: `HTTP ${response.status}${response.statusText ? ` ${response.statusText}` : ''}`,
        responsePreview: cleanPreview(responseText),
        retryAfterMs: retryAfterMs ?? undefined
      };
      throw new DataSourceError(attempt.errorMessage ?? `HTTP ${response.status}`, 'rate-limit', {
        status: response.status,
        attempts: [...upstreamAttempts, attempt],
        retryAt: retryAfterMs ? Date.now() + retryAfterMs : undefined
      });
    }

    if (!response.ok) {
      const upstreamAttempts = embeddedGatewayAttempts(responseText);
      const attempt: ApiAttemptDiagnostic = {
        backend: policy.backend,
        label: policy.label,
        url,
        startedAt: startedIso,
        durationMs,
        outcome: 'http-error',
        status: response.status,
        errorName: 'HTTPError',
        errorMessage: `HTTP ${response.status}${response.statusText ? ` ${response.statusText}` : ''}`,
        responsePreview: cleanPreview(responseText)
      };
      throw new DataSourceError(attempt.errorMessage ?? `HTTP ${response.status}`, 'http', {
        status: response.status,
        attempts: [...upstreamAttempts, attempt]
      });
    }

    try {
      return {
        data: JSON.parse(responseText) as T,
        fetchedAt: Date.now(),
        attempt: {
          backend: policy.backend,
          label: policy.label,
          url,
          startedAt: startedIso,
          durationMs,
          outcome: 'success',
          status: response.status
        }
      };
    } catch (cause) {
      const attempt: ApiAttemptDiagnostic = {
        backend: policy.backend,
        label: policy.label,
        url,
        startedAt: startedIso,
        durationMs,
        outcome: 'parse-error',
        status: response.status,
        errorName: errorName(cause),
        errorMessage: errorMessage(cause),
        responsePreview: cleanPreview(responseText)
      };
      throw new DataSourceError('Ungültige JSON-Antwort', 'parse', {
        status: response.status,
        attempts: [attempt],
        cause
      });
    }
  } catch (cause) {
    if (cause instanceof DataSourceError) throw cause;
    const durationMs = Date.now() - startedAt;
    if (controller.signal.aborted) {
      const kind: DataSourceErrorKind = timedOut ? 'timeout' : 'aborted';
      const attempt: ApiAttemptDiagnostic = {
        backend: policy.backend,
        label: policy.label,
        url,
        startedAt: startedIso,
        durationMs,
        outcome: timedOut ? 'timeout' : 'aborted',
        errorName: timedOut ? 'TimeoutError' : errorName(cause),
        errorMessage: timedOut ? `Zeitüberschreitung nach ${timeoutMs} ms` : errorMessage(cause)
      };
      throw new DataSourceError(attempt.errorMessage ?? 'Anfrage abgebrochen', kind, {
        attempts: [attempt],
        cause
      });
    }

    const attempt: ApiAttemptDiagnostic = {
      backend: policy.backend,
      label: policy.label,
      url,
      startedAt: startedIso,
      durationMs,
      outcome: 'network-error',
      errorName: errorName(cause),
      errorMessage: errorMessage(cause)
    };
    throw new DataSourceError(`${attempt.errorName}: ${attempt.errorMessage}`, 'network', {
      attempts: [attempt],
      cause
    });
  } finally {
    globalThis.clearTimeout(timeout);
  }
}

function waitForTask<T>(task: InFlightTask<T>, signal?: AbortSignal): Promise<NetworkResult<T>> {
  if (signal?.aborted) {
    return Promise.reject(new DataSourceError('Anfrage abgebrochen', 'aborted'));
  }

  task.subscribers += 1;
  return new Promise<NetworkResult<T>>((resolve, reject) => {
    let finished = false;
    const release = () => {
      if (finished) return;
      finished = true;
      signal?.removeEventListener('abort', onAbort);
      task.subscribers = Math.max(0, task.subscribers - 1);
    };
    const onAbort = () => {
      release();
      reject(new DataSourceError('Anfrage abgebrochen', 'aborted'));
    };

    signal?.addEventListener('abort', onAbort, { once: true });
    task.promise.then(
      (value) => {
        if (finished) return;
        release();
        resolve(value);
      },
      (error) => {
        if (finished) return;
        release();
        reject(error);
      }
    );
  });
}

async function fetchJson<T extends object>(
  url: string,
  policy: FetchPolicy,
  signal?: AbortSignal
): Promise<T> {
  throwIfAborted(signal);
  const now = Date.now();
  const currentKey = httpCacheKey(url);
  const cached = await readBestCache<T>([currentKey, legacyHttpCacheKey(url)], policy, now);
  throwIfAborted(signal);

  if (cached?.fresh) {
    if (cached.entry.key !== currentKey) {
      await putApiCache({
        key: currentKey,
        value: cached.entry.value,
        storedAt: cached.entry.storedAt,
        expiresAt: cached.entry.storedAt + policy.freshMs,
        staleUntil: cached.entry.storedAt + policy.staleMs
      });
      throwIfAborted(signal);
    }
    return attachMeta(
      cached.entry.value,
      meta('fresh-cache', cached.entry.storedAt, url, {
        backend: policy.backend,
        originBackend: policy.backend,
        networkAttempted: false,
        cacheAgeMs: now - cached.entry.storedAt,
        cacheKey: currentKey,
        attempts: [cacheHitAttempt(policy.backend, `${policy.label} · URL-Cache`, url, cached.entry.storedAt, now)]
      })
    );
  }

  if (cached && isOffline()) {
    return attachMeta(
      cached.entry.value,
      meta('stale-cache', cached.entry.storedAt, url, {
        backend: policy.backend,
        originBackend: policy.backend,
        networkAttempted: false,
        cacheAgeMs: now - cached.entry.storedAt,
        cacheKey: currentKey,
        fallbackReason: 'offline',
        attempts: [cacheHitAttempt(policy.backend, `${policy.label} · Offline-Cache`, url, cached.entry.storedAt, now)]
      })
    );
  }

  let task = inFlight.get(currentKey) as InFlightTask<T> | undefined;
  if (!task) {
    const controller = new AbortController();
    task = {
      controller,
      subscribers: 0,
      settled: false,
      promise: Promise.resolve(null as never)
    };
    const concreteTask = task;
    concreteTask.promise = networkJson<T>(url, policy, controller)
      .then(async (result) => {
        // Cache the shared result inside the shared task. It therefore remains
        // cached even when an individual UI subscriber navigates away.
        await putApiCache({
          key: currentKey,
          value: result.data,
          storedAt: result.fetchedAt,
          expiresAt: result.fetchedAt + policy.freshMs,
          staleUntil: result.fetchedAt + policy.staleMs
        });
        return result;
      })
      .finally(() => {
        concreteTask.settled = true;
        if (inFlight.get(currentKey) === concreteTask) inFlight.delete(currentKey);
      });
    inFlight.set(currentKey, concreteTask as InFlightTask<unknown>);
  }

  try {
    const result = await waitForTask(task, signal);
    throwIfAborted(signal);
    return attachMeta(
      result.data,
      meta('network', result.fetchedAt, url, {
        backend: policy.backend,
        originBackend: policy.backend,
        networkAttempted: true,
        durationMs: result.attempt.durationMs,
        cacheKey: currentKey,
        attempts: [result.attempt]
      })
    );
  } catch (cause) {
    if (signal?.aborted) throwIfAborted(signal);
    if (cause instanceof DataSourceError && cause.kind === 'aborted') throw cause;
    if (cached && cached.entry.staleUntil > now) {
      const error = cause instanceof DataSourceError
        ? cause
        : new DataSourceError(`${errorName(cause)}: ${errorMessage(cause)}`, 'network');
      return attachMeta(
        cached.entry.value,
        meta('stale-cache', cached.entry.storedAt, url, {
          backend: policy.backend,
          originBackend: policy.backend,
          networkAttempted: true,
          cacheAgeMs: now - cached.entry.storedAt,
          cacheKey: currentKey,
          attempts: error.attempts,
          fallbackReason: fallbackReason(error),
          fallbackStatus: error.status,
          fallbackOrigin: error.status === 503 ? 'remote-overload' : error.status === 429 ? 'remote-limit' : undefined,
          retryAt: error.retryAt ? new Date(error.retryAt).toISOString() : undefined
        })
      );
    }
    throw cause;
  }
}

async function peekCachedJson<T extends object>(
  url: string,
  policy: FetchPolicy,
  signal?: AbortSignal
): Promise<T | null> {
  throwIfAborted(signal);
  const now = Date.now();
  const currentKey = httpCacheKey(url);
  const cached = await readBestCache<T>([currentKey, legacyHttpCacheKey(url)], policy, now);
  throwIfAborted(signal);
  if (!cached?.fresh) return null;
  if (cached.entry.key !== currentKey) {
    await putApiCache({
      key: currentKey,
      value: cached.entry.value,
      storedAt: cached.entry.storedAt,
      expiresAt: cached.entry.storedAt + policy.freshMs,
      staleUntil: cached.entry.storedAt + policy.staleMs
    });
    throwIfAborted(signal);
  }
  return attachMeta(
    cached.entry.value,
    meta('fresh-cache', cached.entry.storedAt, url, {
      backend: policy.backend,
      originBackend: policy.backend,
      networkAttempted: false,
      cacheAgeMs: now - cached.entry.storedAt,
      cacheKey: currentKey,
      attempts: [cacheHitAttempt(policy.backend, `${policy.label} · migrierter URL-Cache`, url, cached.entry.storedAt, now)]
    })
  );
}

function gatewayEndpoint(base: string, route: string): string {
  const normalized = base.trim();
  if (!normalized) throw new Error('Gateway-URL fehlt.');
  const absoluteBase = /^https?:\/\//i.test(normalized)
    ? normalized
    : typeof window !== 'undefined'
      ? new URL(normalized, window.location.origin).toString()
      : normalized;
  const root = absoluteBase.endsWith('/') ? absoluteBase : `${absoluteBase}/`;
  return new URL(route.replace(/^\//, ''), root).toString();
}

function buildSearchALiciousUrl(query: string, pageSize = NETWORK_SEARCH_PAGE_SIZE): string {
  const url = new URL(SEARCH_A_LICIOUS_URL);
  url.searchParams.set('q', query);
  url.searchParams.set('langs', 'de,en,main');
  url.searchParams.set('page', '1');
  url.searchParams.set('page_size', String(pageSize));
  url.searchParams.set('boost_phrase', '1');
  url.searchParams.set('fields', SEARCH_FIELDS.join(','));
  return url.toString();
}

function buildLegacySearchUrl(query: string, pageSize = NETWORK_SEARCH_PAGE_SIZE): string {
  const url = new URL(OFF_LEGACY_SEARCH_URL);
  url.searchParams.set('action', 'process');
  url.searchParams.set('json', '1');
  url.searchParams.set('search_simple', '1');
  url.searchParams.set('search_terms', query);
  url.searchParams.set('page', '1');
  url.searchParams.set('page_size', String(pageSize));
  url.searchParams.set('sort_by', 'popularity');
  url.searchParams.set('lc', 'de');
  url.searchParams.set('cc', 'de');
  url.searchParams.set('fields', SEARCH_FIELDS.join(','));
  return url.toString();
}

function buildGatewaySearchUrl(base: string, query: string, pageSize = NETWORK_SEARCH_PAGE_SIZE): string {
  const url = new URL(gatewayEndpoint(base, 'api/search'));
  url.searchParams.set('q', query);
  url.searchParams.set('page_size', String(pageSize));
  return url.toString();
}

function searchPolicy(backend: SearchBackend): FetchPolicy {
  if (backend === 'gateway') {
    return { bucket: 'search', backend, label: 'Eigener Daten-Gateway', freshMs: SEARCH_FRESH_MS, staleMs: SEARCH_STALE_MS, timeoutMs: 9_000 };
  }
  if (backend === 'search-a-licious') {
    return { bucket: 'search', backend, label: 'Search-a-licious', freshMs: SEARCH_FRESH_MS, staleMs: SEARCH_STALE_MS, timeoutMs: 9_000 };
  }
  return { bucket: 'search', backend, label: 'Open Food Facts Legacy-Suche', freshMs: SEARCH_FRESH_MS, staleMs: SEARCH_STALE_MS, timeoutMs: 10_000 };
}

function searchUrl(backend: SearchBackend, query: string, pageSize: number, gatewayUrl = ''): string {
  if (backend === 'gateway') return buildGatewaySearchUrl(gatewayUrl, query, pageSize);
  if (backend === 'search-a-licious') return buildSearchALiciousUrl(query, pageSize);
  return buildLegacySearchUrl(query, pageSize);
}

function normalizeSearchPayload(
  backend: SearchBackend,
  raw: (SearchResponse | LegacySearchResponse) & { api_meta?: ApiResponseMeta },
  query: string
): SearchResponse {
  if (backend === 'open-food-facts-legacy') {
    const legacy = raw as LegacySearchResponse;
    return {
      hits: legacy.products ?? [],
      count: legacy.count,
      page: legacy.page,
      page_size: legacy.page_size,
      page_count: legacy.page_count,
      api_meta: legacy.api_meta,
      source: 'open-food-facts-legacy',
      query_used: query
    };
  }

  const response = raw as SearchResponse;
  const transportMeta = response.api_meta;
  const upstreamAttempts = response.gateway_attempts ?? [];
  const { gateway_attempts: _transportAttempts, ...responseWithoutTransport } = response;
  return {
    ...responseWithoutTransport,
    hits: response.hits ?? [],
    source: backend === 'gateway' ? (response.source ?? 'gateway') : 'search-a-licious',
    query_used: query,
    api_meta: transportMeta && upstreamAttempts.length
      ? {
          ...transportMeta,
          attempts: [...upstreamAttempts, ...(transportMeta.attempts ?? [])],
          durationMs: [...upstreamAttempts, ...(transportMeta.attempts ?? [])]
            .reduce((sum, attempt) => sum + attempt.durationMs, 0),
          fallbackReason: upstreamAttempts.some((attempt) => attempt.outcome === 'rate-limit')
            ? 'rate-limit'
            : upstreamAttempts.some((attempt) => attempt.outcome === 'network-error')
              ? 'network'
              : upstreamAttempts.some((attempt) => attempt.outcome === 'timeout')
                ? 'timeout'
                : upstreamAttempts.some((attempt) => attempt.outcome === 'http-error')
                  ? 'http'
                  : transportMeta.fallbackReason,
          fallbackStatus: [...upstreamAttempts].reverse().find((attempt) => attempt.status)?.status
            ?? transportMeta.fallbackStatus
        }
      : transportMeta
  };
}

async function searchViaBackend(
  backend: SearchBackend,
  query: string,
  signal?: AbortSignal,
  gatewayUrl = '',
  pageSize = NETWORK_SEARCH_PAGE_SIZE
): Promise<SearchResponse> {
  const url = searchUrl(backend, query, pageSize, gatewayUrl);
  const result = await fetchJson<(SearchResponse | LegacySearchResponse) & { api_meta?: ApiResponseMeta }>(
    url,
    searchPolicy(backend),
    signal
  );
  return normalizeSearchPayload(backend, result, query);
}

function searchBackendOrder(gatewayUrl = ''): SearchBackend[] {
  if (gatewayUrl.trim()) return ['gateway', 'open-food-facts-legacy'];
  // Search-a-licious remains the recommended future full-text engine, but its
  // direct browser endpoint currently has open CORS regressions. Static builds
  // start with the browser-compatible legacy route and use Search-a-licious as
  // a single fallback. Server/gateway runtimes can use it first.
  return typeof window === 'undefined'
    ? ['search-a-licious', 'open-food-facts-legacy']
    : ['open-food-facts-legacy', 'search-a-licious'];
}

function responseAttempts(response: { api_meta?: ApiResponseMeta }): ApiAttemptDiagnostic[] {
  return response.api_meta?.attempts ?? [];
}

function combineResponseMeta(
  response: SearchResponse,
  priorAttempts: ApiAttemptDiagnostic[],
  fallbackError?: DataSourceError
): SearchResponse {
  const existing = response.api_meta;
  const attempts = [...priorAttempts, ...(existing?.attempts ?? [])];
  return {
    ...response,
    api_meta: {
      cacheStatus: existing?.cacheStatus ?? 'network',
      fetchedAt: existing?.fetchedAt ?? new Date().toISOString(),
      sourceUrl: existing?.sourceUrl ?? '',
      backend: existing?.backend,
      originBackend: existing?.originBackend,
      networkAttempted: attempts.some((attempt) => attempt.outcome !== 'cache-hit'),
      durationMs: attempts.reduce((sum, attempt) => sum + attempt.durationMs, 0),
      cacheAgeMs: existing?.cacheAgeMs,
      cacheKey: existing?.cacheKey,
      attempts,
      fallbackReason: fallbackError ? fallbackReason(fallbackError) : existing?.fallbackReason,
      fallbackStatus: fallbackError?.status ?? existing?.fallbackStatus,
      fallbackOrigin: fallbackError?.status === 503
        ? 'remote-overload'
        : fallbackError?.status === 429
          ? 'remote-limit'
          : existing?.fallbackOrigin,
      retryAt: fallbackError?.retryAt ? new Date(fallbackError.retryAt).toISOString() : existing?.retryAt
    }
  };
}

function sliceSearchResponse(response: SearchResponse, pageSize: number): SearchResponse {
  return { ...response, hits: (response.hits ?? []).slice(0, Math.max(1, pageSize)) };
}

async function readQueryCache(
  query: string,
  pageSize: number,
  allowStale = false
): Promise<SearchResponse | null> {
  const key = searchQueryCacheKey(query);
  const now = Date.now();
  const cached = await getApiCache<CachedSearchValue>(key);
  if (!cached || cached.staleUntil <= now) return null;
  const fresh = cached.expiresAt > now;
  if (!fresh && !allowStale) return null;
  const value = cached.value;
  return sliceSearchResponse({
    ...value.response,
    api_meta: meta(fresh ? 'fresh-cache' : 'stale-cache', cached.storedAt, value.sourceUrl, {
      backend: 'query-cache',
      originBackend: value.originBackend,
      networkAttempted: false,
      cacheAgeMs: now - cached.storedAt,
      cacheKey: key,
      fallbackReason: fresh ? undefined : isOffline() ? 'offline' : undefined,
      attempts: [cacheHitAttempt('query-cache', 'Kanonischer Suchcache', value.sourceUrl, cached.storedAt, now)]
    })
  }, pageSize);
}

async function storeQueryCache(query: string, response: SearchResponse): Promise<void> {
  const now = Date.now();
  const storedAt = cacheTimestampFromMeta(response.api_meta, now);
  const hasHits = (response.hits ?? []).length > 0;
  const freshMs = hasHits ? SEARCH_FRESH_MS : EMPTY_SEARCH_FRESH_MS;
  const staleMs = hasHits ? SEARCH_STALE_MS : EMPTY_SEARCH_STALE_MS;
  const responseMeta = response.api_meta;
  const originBackend = responseMeta?.originBackend
    ?? responseMeta?.backend
    ?? (response.source === 'gateway' ? 'gateway' : response.source === 'search-a-licious' ? 'search-a-licious' : 'open-food-facts-legacy');
  await putApiCache<CachedSearchValue>({
    key: searchQueryCacheKey(query),
    value: {
      response: stripMeta(response),
      sourceUrl: responseMeta?.sourceUrl ?? '',
      originBackend
    },
    storedAt,
    expiresAt: storedAt + freshMs,
    staleUntil: storedAt + staleMs
  });
}

async function findMigratableSearchCache(
  query: string,
  requestedPageSize: number,
  gatewayUrl = '',
  signal?: AbortSignal
): Promise<SearchResponse | null> {
  throwIfAborted(signal);
  const sizes = [...new Set([NETWORK_SEARCH_PAGE_SIZE, requestedPageSize, 15, 10])];
  for (const backend of searchBackendOrder(gatewayUrl)) {
    for (const size of sizes) {
      const url = searchUrl(backend, query, size, gatewayUrl);
      const raw = await peekCachedJson<(SearchResponse | LegacySearchResponse) & { api_meta?: ApiResponseMeta }>(
        url,
        searchPolicy(backend),
        signal
      );
      throwIfAborted(signal);
      if (!raw) continue;
      const response = normalizeSearchPayload(backend, raw, query);
      await storeQueryCache(query, response);
      throwIfAborted(signal);
      return sliceSearchResponse(response, requestedPageSize);
    }
  }
  return null;
}

function summarizeAttempts(attempts: ApiAttemptDiagnostic[]): string {
  const unique = new Set<string>();
  for (const attempt of attempts) {
    if (attempt.outcome === 'success' || attempt.outcome === 'cache-hit') continue;
    const status = attempt.status ? `HTTP ${attempt.status}` : null;
    const technical = [attempt.errorName, attempt.errorMessage].filter(Boolean).join(': ');
    unique.add(`${attempt.label}: ${status ?? (technical || attempt.outcome)}`);
  }
  return [...unique].join(' · ');
}

/**
 * Cache-first search with a maximum of two real search requests per click.
 * The canonical query cache is backend-independent, so a result obtained via
 * Search-a-licious fallback is reused before the next legacy request (and vice
 * versa). No local cooldown can disable the search button.
 */
export async function searchFoodCandidates(
  productName: string,
  pageSize: number,
  signal?: AbortSignal,
  options: SearchFoodOptions = {}
): Promise<SearchResponse> {
  throwIfAborted(signal);
  const clean = productName
    .replace(/[()]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, MAX_SEARCH_QUERY_LENGTH)
    .trim();
  if (!clean) return { hits: [], count: 0, source: 'none', query_used: '' };

  const corrected = correctCommonFoodTypos(clean);
  const cached = await readQueryCache(corrected, pageSize);
  throwIfAborted(signal);
  if (cached) return cached;

  const migrated = await findMigratableSearchCache(corrected, pageSize, options.gatewayUrl, signal);
  throwIfAborted(signal);
  if (migrated) return migrated;

  const staleQueryCache = await readQueryCache(corrected, pageSize, true);
  throwIfAborted(signal);
  if (staleQueryCache && isOffline()) return staleQueryCache;

  const attempts: ApiAttemptDiagnostic[] = [];
  const errors: DataSourceError[] = [];

  for (const backend of searchBackendOrder(options.gatewayUrl)) {
    try {
      const response = await searchViaBackend(
        backend,
        corrected,
        signal,
        options.gatewayUrl,
        NETWORK_SEARCH_PAGE_SIZE
      );
      const withPrior = combineResponseMeta(response, attempts, errors.at(-1));
      attempts.push(...responseAttempts(response));
      // A valid empty response is authoritative for this query. Falling through
      // would spend another search request despite the first source being
      // reachable and would amplify public API load on every zero-result query.
      await storeQueryCache(corrected, withPrior);
      throwIfAborted(signal);
      return sliceSearchResponse(withPrior, pageSize);
    } catch (cause) {
      if (cause instanceof DataSourceError && cause.kind === 'aborted') throw cause;
      const error = cause instanceof DataSourceError
        ? cause
        : new DataSourceError(`${errorName(cause)}: ${errorMessage(cause)}`, 'network');
      errors.push(error);
      attempts.push(...error.attempts);
      // A configured gateway already performed its own upstream fallback when
      // it returns embedded diagnostics. Repeating the same public requests in
      // the browser would increase load without adding a genuinely new path.
      if (backend === 'gateway' && error.attempts.some((attempt) => attempt.backend !== 'gateway')) break;
    }
  }

  if (staleQueryCache) {
    throwIfAborted(signal);
    const staleMeta = staleQueryCache.api_meta;
    const lastSearchError = errors.at(-1);
    return {
      ...staleQueryCache,
      api_meta: {
        ...(staleMeta ?? meta('stale-cache', Date.now(), '')),
        cacheStatus: 'stale-cache',
        networkAttempted: true,
        attempts: [...attempts, ...(staleMeta?.attempts ?? [])],
        fallbackReason: lastSearchError ? fallbackReason(lastSearchError) : 'network',
        fallbackStatus: lastSearchError?.status,
        retryAt: (() => {
          const retryAt = lastSearchError?.retryAt;
          return retryAt ? new Date(retryAt).toISOString() : undefined;
        })()
      }
    };
  }

  const details = summarizeAttempts(attempts);
  throw new DataSourceError(
    `Keine öffentliche Produktsuche war erreichbar${details ? ` (${details})` : ''}.`,
    errors.at(-1)?.kind ?? 'network',
    {
      status: errors.at(-1)?.status,
      attempts,
      retryAt: errors.at(-1)?.retryAt,
      cause: errors.at(-1)
    }
  );
}

function productToSearchHit(product: OffProduct | undefined): SearchHit {
  if (!product) return {};
  return {
    code: product.code,
    product_name: product.product_name,
    product_name_de: product.product_name_de,
    generic_name: product.generic_name,
    generic_name_de: product.generic_name_de,
    brands: product.brands,
    quantity: product.quantity,
    product_quantity: product.product_quantity,
    product_quantity_unit: product.product_quantity_unit,
    serving_size: product.serving_size,
    serving_quantity: product.serving_quantity,
    nutrition_data_per: product.nutrition_data_per,
    nutrition_data_prepared_per: product.nutrition_data_prepared_per,
    countries_tags: product.countries_tags,
    categories_tags: product.categories_tags,
    nutriments: product.nutriments,
    image_front_url: product.image_front_url,
    data_quality_errors_tags: product.data_quality_errors_tags,
    completeness: 1
  };
}

function mergeProducts(base: OffProduct | undefined, extra: OffProduct | undefined): OffProduct | undefined {
  if (!base) return extra;
  if (!extra) return base;
  return {
    ...base,
    ...extra,
    code: extra.code ?? base.code,
    product_name: extra.product_name ?? base.product_name,
    product_name_de: extra.product_name_de ?? base.product_name_de,
    generic_name: extra.generic_name ?? base.generic_name,
    generic_name_de: extra.generic_name_de ?? base.generic_name_de,
    brands: extra.brands ?? base.brands,
    quantity: extra.quantity ?? base.quantity,
    product_quantity: extra.product_quantity ?? base.product_quantity,
    product_quantity_unit: extra.product_quantity_unit ?? base.product_quantity_unit,
    serving_size: extra.serving_size ?? base.serving_size,
    serving_quantity: extra.serving_quantity ?? base.serving_quantity,
    nutriments: { ...(base.nutriments ?? {}), ...(extra.nutriments ?? {}) }
  };
}

function hasCarbohydrateData(product: OffProduct | undefined): boolean {
  const nutrients = product?.nutriments ?? {};
  return [
    nutrients.carbohydrates_100g,
    nutrients.carbohydrates_100ml,
    nutrients.carbohydrates_prepared_100g,
    nutrients.carbohydrates_prepared_100ml
  ].some((value) => typeof value === 'number' && Number.isFinite(value));
}

function buildV3ProductUrl(code: string): string {
  const url = new URL(`${OFF_V3_PRODUCT_URL}/${encodeURIComponent(code)}.json`);
  url.searchParams.set('lc', 'de');
  url.searchParams.set('cc', 'de');
  url.searchParams.set('tags_lc', 'de');
  url.searchParams.set('fields', PRODUCT_FIELDS.join(','));
  return url.toString();
}

function buildV2ProductUrl(code: string): string {
  const url = new URL(`${OFF_V2_PRODUCT_URL}/${encodeURIComponent(code)}.json`);
  url.searchParams.set('lc', 'de');
  url.searchParams.set('cc', 'de');
  url.searchParams.set('fields', PRODUCT_FIELDS.join(','));
  return url.toString();
}

function buildGatewayProductUrl(base: string, code: string): string {
  return gatewayEndpoint(base, `api/product/${encodeURIComponent(code)}`);
}

function productPolicy(backend: 'gateway' | 'open-food-facts-v3' | 'open-food-facts-v2'): FetchPolicy {
  if (backend === 'gateway') {
    return { bucket: 'product', backend, label: 'Eigener Produkt-Gateway', freshMs: PRODUCT_FRESH_MS, staleMs: PRODUCT_STALE_MS, timeoutMs: 9_000 };
  }
  if (backend === 'open-food-facts-v3') {
    return { bucket: 'product', backend, label: 'Open Food Facts API v3.6', freshMs: PRODUCT_FRESH_MS, staleMs: PRODUCT_STALE_MS, timeoutMs: 9_000 };
  }
  return { bucket: 'product', backend, label: 'Open Food Facts API v2 (Fallback)', freshMs: PRODUCT_FRESH_MS, staleMs: PRODUCT_STALE_MS, timeoutMs: 9_000 };
}

async function readProductSnapshot(code: string, allowStale = false): Promise<OffProductResponse | null> {
  const key = productSnapshotCacheKey(code);
  const now = Date.now();
  const cached = await getApiCache<CachedProductValue>(key);
  if (!cached || cached.staleUntil <= now) return null;
  const fresh = cached.expiresAt > now;
  if (!fresh && !allowStale) return null;
  return {
    ...cached.value.response,
    api_meta: meta(fresh ? 'fresh-cache' : 'stale-cache', cached.storedAt, cached.value.sourceUrl, {
      backend: 'product-cache',
      originBackend: cached.value.originBackend,
      networkAttempted: false,
      cacheAgeMs: now - cached.storedAt,
      cacheKey: key,
      fallbackReason: fresh ? undefined : isOffline() ? 'offline' : undefined,
      attempts: [cacheHitAttempt('product-cache', 'Kanonischer Produktcache', cached.value.sourceUrl, cached.storedAt, now)]
    })
  };
}

async function storeProductSnapshot(
  code: string,
  response: OffProductResponse,
  originBackend?: ApiBackend,
  sourceUrl?: string
): Promise<void> {
  const now = Date.now();
  const responseMeta = response.api_meta;
  const storedAt = cacheTimestampFromMeta(responseMeta, now);
  await putApiCache<CachedProductValue>({
    key: productSnapshotCacheKey(code),
    value: {
      response: stripMeta(response),
      sourceUrl: sourceUrl ?? responseMeta?.sourceUrl ?? '',
      originBackend: originBackend ?? responseMeta?.originBackend ?? responseMeta?.backend ?? 'open-food-facts-v3'
    },
    storedAt,
    expiresAt: storedAt + PRODUCT_FRESH_MS,
    staleUntil: storedAt + PRODUCT_STALE_MS
  });
}

async function fetchProductBackend(
  backend: 'gateway' | 'open-food-facts-v3' | 'open-food-facts-v2',
  code: string,
  signal?: AbortSignal,
  gatewayUrl = ''
): Promise<OffProductResponse> {
  const url = backend === 'gateway'
    ? buildGatewayProductUrl(gatewayUrl, code)
    : backend === 'open-food-facts-v3'
      ? buildV3ProductUrl(code)
      : buildV2ProductUrl(code);
  const response = await fetchJson<OffProductResponse>(url, productPolicy(backend), signal);
  const { gateway_attempts: gatewayAttempts = [], ...responseWithoutTransport } = response;
  if (backend !== 'gateway' || !gatewayAttempts.length || !response.api_meta) return responseWithoutTransport;
  const attempts = [...gatewayAttempts, ...(response.api_meta.attempts ?? [])];
  return {
    ...responseWithoutTransport,
    api_meta: {
      ...response.api_meta,
      attempts,
      durationMs: attempts.reduce((sum, attempt) => sum + attempt.durationMs, 0),
      fallbackReason: gatewayAttempts.some((attempt) => attempt.outcome === 'rate-limit')
        ? 'rate-limit'
        : gatewayAttempts.some((attempt) => attempt.outcome === 'network-error')
          ? 'network'
          : gatewayAttempts.some((attempt) => attempt.outcome === 'timeout')
            ? 'timeout'
            : gatewayAttempts.some((attempt) => attempt.outcome === 'http-error')
              ? 'http'
              : response.api_meta.fallbackReason,
      fallbackStatus: [...gatewayAttempts].reverse().find((attempt) => attempt.status)?.status
        ?? response.api_meta.fallbackStatus
    }
  };
}

async function findMigratableProductCache(
  code: string,
  signal?: AbortSignal
): Promise<OffProductResponse | null> {
  throwIfAborted(signal);
  for (const backend of ['open-food-facts-v3', 'open-food-facts-v2'] as const) {
    const url = backend === 'open-food-facts-v3' ? buildV3ProductUrl(code) : buildV2ProductUrl(code);
    const response = await peekCachedJson<OffProductResponse>(url, productPolicy(backend), signal);
    throwIfAborted(signal);
    if (!response?.product) continue;
    if (backend === 'open-food-facts-v2' || hasCarbohydrateData(response.product)) {
      await storeProductSnapshot(code, response, backend, url);
      throwIfAborted(signal);
    }
    return response;
  }
  return null;
}

function mergeAttemptDiagnostics(...groups: ApiAttemptDiagnostic[][]): ApiAttemptDiagnostic[] {
  const seen = new Set<string>();
  const merged: ApiAttemptDiagnostic[] = [];
  for (const attempt of groups.flat()) {
    const key = [
      attempt.startedAt,
      attempt.backend,
      attempt.label,
      attempt.url,
      attempt.outcome,
      attempt.status ?? '',
      attempt.errorName ?? '',
      attempt.errorMessage ?? ''
    ].join('|');
    if (seen.has(key)) continue;
    seen.add(key);
    merged.push(attempt);
  }
  return merged;
}

function combineProductMeta(
  response: OffProductResponse,
  priorAttempts: ApiAttemptDiagnostic[],
  fallbackError?: DataSourceError
): OffProductResponse {
  const existing = response.api_meta;
  const attempts = mergeAttemptDiagnostics(priorAttempts, existing?.attempts ?? []);
  return {
    ...response,
    api_meta: {
      cacheStatus: existing?.cacheStatus ?? 'network',
      fetchedAt: existing?.fetchedAt ?? new Date().toISOString(),
      sourceUrl: existing?.sourceUrl ?? '',
      backend: existing?.backend,
      originBackend: existing?.originBackend,
      networkAttempted: attempts.some((attempt) => attempt.outcome !== 'cache-hit'),
      durationMs: attempts.reduce((sum, attempt) => sum + attempt.durationMs, 0),
      cacheAgeMs: existing?.cacheAgeMs,
      cacheKey: existing?.cacheKey,
      attempts,
      fallbackReason: fallbackError ? fallbackReason(fallbackError) : existing?.fallbackReason,
      fallbackStatus: fallbackError?.status ?? existing?.fallbackStatus,
      fallbackOrigin: fallbackError?.status === 503
        ? 'remote-overload'
        : fallbackError?.status === 429
          ? 'remote-limit'
          : existing?.fallbackOrigin,
      retryAt: fallbackError?.retryAt ? new Date(fallbackError.retryAt).toISOString() : existing?.retryAt
    }
  };
}

export async function getProductByBarcode(
  code: string,
  signal?: AbortSignal,
  options: ProductRequestOptions = {}
): Promise<OffProductResponse> {
  throwIfAborted(signal);
  const normalizedCode = code.replace(/\D/g, '');
  if (!/^\d{8,14}$/.test(normalizedCode)) {
    throw new DataSourceError('Ungültiger Barcode: erwartet werden 8 bis 14 Ziffern.', 'http', { status: 400 });
  }

  const cached = await readProductSnapshot(normalizedCode);
  throwIfAborted(signal);
  const cachedIsCompatibilityComplete = cached && (
    hasCarbohydrateData(cached.product)
    || cached.api_meta?.originBackend === 'gateway'
    || cached.api_meta?.originBackend === 'open-food-facts-v2'
  );
  if (cachedIsCompatibilityComplete) return cached;

  const migrated = cached ? null : await findMigratableProductCache(normalizedCode, signal);
  throwIfAborted(signal);
  const seedSnapshot = cached ?? migrated;
  const migratedIsCompatibilityComplete = migrated && (
    hasCarbohydrateData(migrated.product)
    || migrated.api_meta?.originBackend === 'open-food-facts-v2'
  );
  if (migratedIsCompatibilityComplete) return migrated;

  const staleSnapshot = await readProductSnapshot(normalizedCode, true);
  throwIfAborted(signal);
  if (staleSnapshot && isOffline()) return staleSnapshot;

  const backends: Array<'gateway' | 'open-food-facts-v3' | 'open-food-facts-v2'> = options.gatewayUrl?.trim()
    ? ['gateway', 'open-food-facts-v3', 'open-food-facts-v2']
    : ['open-food-facts-v3', 'open-food-facts-v2'];
  const attempts: ApiAttemptDiagnostic[] = [];
  const errors: DataSourceError[] = [];
  let partialProduct = seedSnapshot?.product;
  let partialResponse = seedSnapshot;
  let partialBackend: ApiBackend = seedSnapshot?.api_meta?.originBackend ?? 'open-food-facts-v3';
  let reachableWithoutProduct = false;

  for (const backend of backends) {
    // A migrated v3/v2 cache entry without carbohydrate data is still useful,
    // but the canonical product request should try the missing compatibility
    // source exactly once before accepting the partial document.
    if (seedSnapshot?.product && seedSnapshot.api_meta?.originBackend === backend) continue;

    try {
      const priorAttempts = [...attempts];
      const response = await fetchProductBackend(backend, normalizedCode, signal, options.gatewayUrl);
      throwIfAborted(signal);
      attempts.push(...responseAttempts(response));
      if (!response.product) reachableWithoutProduct = true;
      partialProduct = mergeProducts(partialProduct, response.product);
      if (!partialProduct) continue;

      partialBackend = backend;
      partialResponse = combineProductMeta({ ...response, product: partialProduct }, priorAttempts, errors.at(-1));
      const compatibilityComplete = backend === 'gateway'
        || backend === 'open-food-facts-v2'
        || hasCarbohydrateData(partialProduct);
      if (!compatibilityComplete) continue;

      await storeProductSnapshot(normalizedCode, partialResponse, backend, response.api_meta?.sourceUrl);
      throwIfAborted(signal);
      return partialResponse;
    } catch (cause) {
      if (signal?.aborted) throwIfAborted(signal);
      if (cause instanceof DataSourceError && cause.kind === 'aborted') throw cause;
      const error = cause instanceof DataSourceError
        ? cause
        : new DataSourceError(`${errorName(cause)}: ${errorMessage(cause)}`, 'network');
      errors.push(error);
      attempts.push(...error.attempts);
      if (backend === 'gateway' && (
        error.status === 404
        || error.attempts.some((attempt) => attempt.backend !== 'gateway')
      )) break;
    }
  }

  if (partialProduct) {
    const bestAvailable = combineProductMeta(
      { ...(partialResponse ?? { status: 'success' }), product: partialProduct },
      attempts,
      errors.at(-1)
    );
    if (!errors.length) {
      await storeProductSnapshot(
        normalizedCode,
        bestAvailable,
        partialBackend,
        bestAvailable.api_meta?.sourceUrl
      );
      throwIfAborted(signal);
    }
    return bestAvailable;
  }

  if (staleSnapshot) {
    throwIfAborted(signal);
    const lastProductError = errors.at(-1);
    return {
      ...staleSnapshot,
      api_meta: {
        ...(staleSnapshot.api_meta ?? meta('stale-cache', Date.now(), '')),
        cacheStatus: 'stale-cache',
        networkAttempted: true,
        attempts: mergeAttemptDiagnostics(attempts, staleSnapshot.api_meta?.attempts ?? []),
        fallbackReason: lastProductError ? fallbackReason(lastProductError) : 'network',
        fallbackStatus: lastProductError?.status,
        retryAt: (() => {
          const retryAt = lastProductError?.retryAt;
          return retryAt ? new Date(retryAt).toISOString() : undefined;
        })()
      }
    };
  }

  if (reachableWithoutProduct || errors.at(-1)?.status === 404) {
    throw new DataSourceError('Für diesen Barcode wurde kein Produktdatensatz gefunden.', 'http', {
      status: 404,
      attempts: mergeAttemptDiagnostics(attempts),
      cause: errors.at(-1)
    });
  }

  const details = summarizeAttempts(attempts);
  throw new DataSourceError(
    `Produktdetails konnten nicht geladen werden${details ? ` (${details})` : ''}.`,
    errors.at(-1)?.kind ?? 'network',
    {
      status: errors.at(-1)?.status,
      attempts: mergeAttemptDiagnostics(attempts),
      retryAt: errors.at(-1)?.retryAt,
      cause: errors.at(-1)
    }
  );
}

export async function getSearchDocumentByBarcode(
  code: string,
  signal?: AbortSignal,
  options: ProductRequestOptions = {}
): Promise<SearchHit> {
  throwIfAborted(signal);
  const normalizedCode = code.replace(/\D/g, '');
  const snapshot = await readProductSnapshot(normalizedCode);
  throwIfAborted(signal);
  if (snapshot?.product && hasCarbohydrateData(snapshot.product)) {
    const hit = productToSearchHit(snapshot.product);
    hit.api_meta = snapshot.api_meta;
    return hit;
  }

  const existingProduct = snapshot?.product;
  let response: OffProductResponse;
  try {
    // v2 is deprecated but remains a compact compatibility fallback when a v3
    // response omitted nutrition fields. It is never the primary product API.
    response = await fetchProductBackend('open-food-facts-v2', normalizedCode, signal, options.gatewayUrl);
    throwIfAborted(signal);
  } catch (cause) {
    if (signal?.aborted) throwIfAborted(signal);
    if (snapshot?.product) {
      const hit = productToSearchHit(snapshot.product);
      if (cause instanceof DataSourceError) {
        hit.api_meta = {
          ...(snapshot.api_meta ?? meta('stale-cache', Date.now(), '')),
          cacheStatus: snapshot.api_meta?.cacheStatus ?? 'fresh-cache',
          attempts: mergeAttemptDiagnostics(cause.attempts, snapshot.api_meta?.attempts ?? []),
          fallbackReason: fallbackReason(cause),
          fallbackStatus: cause.status
        };
      }
      return hit;
    }
    throw cause;
  }

  const mergedProduct = mergeProducts(existingProduct, response.product);
  const mergedResponse = { ...response, product: mergedProduct };
  if (mergedProduct) {
    await storeProductSnapshot(normalizedCode, mergedResponse, 'open-food-facts-v2', response.api_meta?.sourceUrl);
    throwIfAborted(signal);
  }
  const hit = productToSearchHit(mergedProduct);
  hit.api_meta = response.api_meta;
  return hit;
}
