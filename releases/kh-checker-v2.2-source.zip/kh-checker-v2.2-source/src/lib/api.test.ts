import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { DataSourceError, clearApiGovernor, getProductByBarcode, searchFoodCandidates } from './api';
import { clearApiCache } from './storage';

beforeEach(async () => {
  clearApiGovernor();
  await clearApiCache();
  vi.useRealTimers();
});

afterEach(async () => {
  vi.unstubAllGlobals();
  vi.useRealTimers();
  clearApiGovernor();
  await clearApiCache();
});

function jsonResponse(data: unknown, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...headers }
  });
}

describe('v2.2 cache-first public API search', () => {
  it('starts with the browser-compatible OFF search route in a browser runtime', async () => {
    vi.stubGlobal('window', {});
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = new URL(String(input));
      if (url.hostname === 'world.openfoodfacts.org' && url.pathname === '/cgi/search.pl') {
        return jsonResponse({
          products: [{ code: 'browser-1', product_name_de: 'Salzstangen' }],
          count: 1,
          page: 1,
          page_size: 20
        });
      }
      throw new Error(`unexpected URL: ${url}`);
    });
    vi.stubGlobal('fetch', fetchMock);

    const result = await searchFoodCandidates('Salzstangen browser route', 10);

    expect(result.hits.map((hit) => hit.code)).toEqual(['browser-1']);
    expect(result.source).toBe('open-food-facts-legacy');
    expect(result.api_meta?.cacheStatus).toBe('network');
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('falls back once and exposes the original browser error in diagnostics', async () => {
    vi.stubGlobal('window', {});
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = new URL(String(input));
      if (url.hostname === 'world.openfoodfacts.org') throw new TypeError('Failed to fetch');
      return jsonResponse({ hits: [{ code: 'fallback-1', product_name: 'Fallback product' }], count: 1 });
    });
    vi.stubGlobal('fetch', fetchMock);

    const result = await searchFoodCandidates('browser fallback diagnostics', 10);

    expect(result.hits[0]?.code).toBe('fallback-1');
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(result.api_meta?.attempts?.map((attempt) => attempt.outcome)).toEqual([
      'network-error',
      'success'
    ]);
    expect(result.api_meta?.attempts?.[0]?.errorName).toBe('TypeError');
    expect(result.api_meta?.attempts?.[0]?.errorMessage).toBe('Failed to fetch');
  });

  it('reuses a backend-independent canonical cache for Kinder Bueno spelling variants', async () => {
    vi.stubGlobal('window', {});
    const fetchMock = vi.fn(async () => jsonResponse({
      products: [{ code: '8000500037560', product_name: 'Kinder Bueno', quantity: '2 x 21.5 g' }],
      count: 1
    }));
    vi.stubGlobal('fetch', fetchMock);

    const first = await searchFoodCandidates('Kinder Bueno', 10);
    const second = await searchFoodCandidates('Kinderbueno', 10);

    expect(first.hits[0]?.code).toBe('8000500037560');
    expect(second.hits[0]?.code).toBe('8000500037560');
    expect(second.api_meta?.cacheStatus).toBe('fresh-cache');
    expect(second.api_meta?.backend).toBe('query-cache');
    expect(second.api_meta?.networkAttempted).toBe(false);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('never returns a cached search result to an already aborted UI operation', async () => {
    vi.stubGlobal('window', {});
    const fetchMock = vi.fn(async () => jsonResponse({
      products: [{ code: 'abort-cache-1', product_name: 'Cached result' }],
      count: 1
    }));
    vi.stubGlobal('fetch', fetchMock);

    await searchFoodCandidates('abort cached operation 2207', 10);
    const controller = new AbortController();
    controller.abort();

    await expect(searchFoodCandidates('abort cached operation 2207', 10, controller.signal)).rejects.toMatchObject({
      name: 'DataSourceError',
      kind: 'aborted'
    });
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('deduplicates identical concurrent network requests and caches the shared result', async () => {
    let resolveResponse!: (value: Response) => void;
    const fetchMock = vi.fn(() => new Promise<Response>((resolve) => { resolveResponse = resolve; }));
    vi.stubGlobal('fetch', fetchMock);

    const first = searchFoodCandidates('Concurrent cache test 2201', 10);
    const second = searchFoodCandidates('Concurrent cache test 2201', 10);
    await vi.waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));
    resolveResponse(jsonResponse({ hits: [{ code: '1', product_name: 'Shared' }], count: 1 }));

    const [a, b] = await Promise.all([first, second]);
    const third = await searchFoodCandidates('Concurrent cache test 2201', 10);

    expect(a.hits).toHaveLength(1);
    expect(b.hits).toHaveLength(1);
    expect(third.api_meta?.cacheStatus).toBe('fresh-cache');
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });


  it('keeps the shared request alive when a UI retry aborts only its first subscriber', async () => {
    vi.stubGlobal('window', {});
    let resolveResponse!: (value: Response) => void;
    const fetchMock = vi.fn(() => new Promise<Response>((resolve) => { resolveResponse = resolve; }));
    vi.stubGlobal('fetch', fetchMock);

    const firstController = new AbortController();
    const first = searchFoodCandidates('instant retry shared task 2204', 10, firstController.signal)
      .then(() => null, (error: unknown) => error);
    await vi.waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));
    firstController.abort();
    await expect(first).resolves.toMatchObject({ name: 'DataSourceError', kind: 'aborted' });

    const retry = searchFoodCandidates('instant retry shared task 2204', 10);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    resolveResponse(jsonResponse({ products: [{ code: 'retry-1', product_name: 'Shared retry' }], count: 1 }));

    const result = await retry;
    expect(result.hits[0]?.code).toBe('retry-1');
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('accepts a valid empty response without spending a second public search request', async () => {
    vi.stubGlobal('window', {});
    const fetchMock = vi.fn(async () => jsonResponse({ products: [], count: 0 }));
    vi.stubGlobal('fetch', fetchMock);

    const first = await searchFoodCandidates('definitely empty query 2205', 10);
    const second = await searchFoodCandidates('definitely empty query 2205', 10);

    expect(first.hits).toEqual([]);
    expect(second.api_meta?.cacheStatus).toBe('fresh-cache');
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('limits the transmitted search term to 120 characters', async () => {
    vi.stubGlobal('window', {});
    let transmitted = '';
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = new URL(String(input));
      transmitted = url.searchParams.get('search_terms') ?? '';
      return jsonResponse({ products: [], count: 0 });
    });
    vi.stubGlobal('fetch', fetchMock);

    await searchFoodCandidates(`Salzstangen ${'x'.repeat(300)}`, 10);

    expect(transmitted.length).toBeLessThanOrEqual(120);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('does not repeat upstream calls in the browser when a gateway returned embedded diagnostics', async () => {
    vi.stubGlobal('window', {});
    const upstreamAttempt = {
      backend: 'search-a-licious',
      label: 'Search-a-licious',
      url: 'https://search.openfoodfacts.org/search?q=test',
      startedAt: new Date().toISOString(),
      durationMs: 42,
      outcome: 'network-error',
      errorName: 'TypeError',
      errorMessage: 'fetch failed'
    };
    const fetchMock = vi.fn(async () => jsonResponse({ error: 'failed', attempts: [upstreamAttempt] }, 502));
    vi.stubGlobal('fetch', fetchMock);

    await expect(searchFoodCandidates('gateway authoritative failure 2206', 10, undefined, {
      gatewayUrl: 'https://gateway.example/'
    })).rejects.toMatchObject({ name: 'DataSourceError' });

    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('treats Retry-After as diagnostics only and never installs a local request lock', async () => {
    vi.stubGlobal('window', {});
    const fetchMock = vi.fn(async () => jsonResponse({ error: 'limit' }, 429, { 'Retry-After': '12' }));
    vi.stubGlobal('fetch', fetchMock);

    await expect(searchFoodCandidates('rate limit no lock a', 10)).rejects.toMatchObject({
      name: 'DataSourceError',
      kind: 'rate-limit'
    });
    await expect(searchFoodCandidates('rate limit no lock b', 10)).rejects.toBeInstanceOf(DataSourceError);

    // Two backends are attempted for each click; the second click is not blocked locally.
    expect(fetchMock).toHaveBeenCalledTimes(4);
  });

  it('keeps stale cached search data when both public backends later fail', async () => {
    vi.stubGlobal('window', {});
    const start = new Date('2026-01-01T10:00:00Z');
    vi.useFakeTimers();
    vi.setSystemTime(start);
    const fetchMock = vi.fn(async () => jsonResponse({
      products: [{ code: 'stale-1', product_name: 'Cached product' }],
      count: 1
    }));
    vi.stubGlobal('fetch', fetchMock);

    await searchFoodCandidates('stale cache recovery 2202', 10);
    vi.setSystemTime(new Date(start.getTime() + 25 * 60 * 60 * 1000));
    fetchMock.mockImplementation(async () => { throw new TypeError('Failed to fetch'); });

    const result = await searchFoodCandidates('stale cache recovery 2202', 10);
    const secondStaleResult = await searchFoodCandidates('stale cache recovery 2202', 10);

    expect(result.hits[0]?.code).toBe('stale-1');
    expect(result.api_meta?.cacheStatus).toBe('stale-cache');
    expect(result.api_meta?.networkAttempted).toBe(true);
    expect(result.api_meta?.attempts?.some((attempt) => attempt.errorMessage === 'Failed to fetch')).toBe(true);
    expect(secondStaleResult.api_meta?.cacheStatus).toBe('stale-cache');
    // The stale result keeps its original timestamp and is not promoted to a
    // fresh 24-hour canonical cache entry after the failed refresh.
    expect(fetchMock).toHaveBeenCalledTimes(3);
  });

  it('preserves exact endpoint diagnostics when no source is reachable', async () => {
    vi.stubGlobal('window', {});
    vi.stubGlobal('fetch', vi.fn(async () => { throw new TypeError('Failed to fetch'); }));

    try {
      await searchFoodCandidates('diagnostic hard failure 2203', 10);
      throw new Error('expected DataSourceError');
    } catch (error) {
      expect(error).toBeInstanceOf(DataSourceError);
      const typed = error as DataSourceError;
      expect(typed.attempts).toHaveLength(2);
      expect(typed.attempts.every((attempt) => attempt.errorName === 'TypeError')).toBe(true);
      expect(typed.attempts.every((attempt) => attempt.url.startsWith('https://'))).toBe(true);
    }
  });
});

describe('v2.2 product cache', () => {
  it('reuses barcode product details without a second API call', async () => {
    const fetchMock = vi.fn(async () => jsonResponse({
      status: 'success',
      product: {
        code: '8000500037560',
        product_name: 'Kinder Bueno',
        serving_size: '21.5 g',
        serving_quantity: 21.5,
        nutriments: { carbohydrates_100g: 49.5 }
      }
    }));
    vi.stubGlobal('fetch', fetchMock);

    const first = await getProductByBarcode('8000500037560');
    const second = await getProductByBarcode('8000500037560');

    expect(first.product?.serving_quantity).toBe(21.5);
    expect(second.api_meta?.cacheStatus).toBe('fresh-cache');
    expect(second.api_meta?.backend).toBe('product-cache');
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });


  it('merges the compact v2 fallback when v3 omits carbohydrate data', async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = new URL(String(input));
      if (url.pathname.includes('/api/v3.6/product/')) {
        return jsonResponse({
          status: 'success',
          product: {
            code: '8000500037560',
            product_name: 'Kinder Bueno',
            quantity: '2 x 21.5 g',
            serving_size: '21.5 g',
            serving_quantity: 21.5
          }
        });
      }
      if (url.pathname.includes('/api/v2/product/')) {
        return jsonResponse({
          status: 'success',
          product: {
            code: '8000500037560',
            nutriments: { carbohydrates_100g: 49.5 }
          }
        });
      }
      throw new Error(`unexpected URL: ${url}`);
    });
    vi.stubGlobal('fetch', fetchMock);

    const first = await getProductByBarcode('8000500037560');
    const second = await getProductByBarcode('8000500037560');

    expect(first.product?.serving_quantity).toBe(21.5);
    expect(first.product?.nutriments?.carbohydrates_100g).toBe(49.5);
    expect(first.api_meta?.attempts?.map((attempt) => attempt.backend)).toEqual([
      'open-food-facts-v3',
      'open-food-facts-v2'
    ]);
    expect(second.api_meta?.cacheStatus).toBe('fresh-cache');
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it('returns useful v3 product data after a failed v2 enrichment without a duplicate request', async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = new URL(String(input));
      if (url.pathname.includes('/api/v3.6/product/')) {
        return jsonResponse({
          status: 'success',
          product: {
            code: '40000000',
            product_name: 'Teilprodukt',
            serving_size: '20 g'
          }
        });
      }
      throw new TypeError('Failed to fetch');
    });
    vi.stubGlobal('fetch', fetchMock);

    const result = await getProductByBarcode('40000000');

    expect(result.product?.product_name).toBe('Teilprodukt');
    expect(result.api_meta?.fallbackReason).toBe('network');
    expect(result.api_meta?.attempts?.map((attempt) => attempt.outcome)).toEqual([
      'success',
      'network-error'
    ]);
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it('reports a reachable product-not-found response as HTTP 404 instead of a network error', async () => {
    const fetchMock = vi.fn(async () => jsonResponse({ status: 'failure', code: '12345678' }));
    vi.stubGlobal('fetch', fetchMock);

    await expect(getProductByBarcode('12345678')).rejects.toMatchObject({
      name: 'DataSourceError',
      kind: 'http',
      status: 404
    });
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it('treats a gateway 404 with embedded upstream diagnostics as authoritative', async () => {
    const upstreamAttempt = {
      backend: 'open-food-facts-v3',
      label: 'Open Food Facts API v3.6',
      url: 'https://world.openfoodfacts.org/api/v3.6/product/12345678.json',
      startedAt: new Date().toISOString(),
      durationMs: 18,
      outcome: 'success',
      status: 200
    };
    const fetchMock = vi.fn(async () => jsonResponse({
      error: 'Produktabruf fehlgeschlagen.',
      attempts: [upstreamAttempt]
    }, 404));
    vi.stubGlobal('fetch', fetchMock);

    await expect(getProductByBarcode('12345678', undefined, {
      gatewayUrl: 'https://gateway.example/'
    })).rejects.toMatchObject({ kind: 'http', status: 404 });
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
});
